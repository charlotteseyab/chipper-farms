<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Concerns\BelongsToOrganizationThroughRelation;
class HealthRecord extends Model
{
    use HasFactory, BelongsToOrganizationThroughRelation;

    protected static function organizationRelation(): string
    {
        return 'pig';
    }

    protected $fillable = [
        'pig_id',
        'record_date',
        'condition',
        'severity',
        'symptoms',
        'diagnosis',
        'treatment_plan',
        'treatment_status',
        'outcome',
        'resolved_at',
        'resolution_notes',
        'recorded_by',
    ];

    protected $casts = [
        'record_date' => 'date',
        'resolved_at' => 'date',
    ];

    public function pig(): BelongsTo
    {
        return $this->belongsTo(PigManagement::class, 'pig_id')->withTrashed();
    }

    public function recordedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'recorded_by');
    }
}

