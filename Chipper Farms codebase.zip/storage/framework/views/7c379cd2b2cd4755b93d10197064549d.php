<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        :root{
            --inv-bg: #f4f7fb;
            --inv-panel: #ffffff;
            --inv-panel-soft: #f8fbff;
            --inv-text: #0f172a;
            --inv-muted: #64748b;
            --inv-line: #e2e8f0;
            --inv-line-soft: #edf2f7;
            --inv-primary: #2563eb;
            --inv-primary-soft: #eff6ff;
            --inv-success: #15803d;
            --inv-success-soft: #ecfdf3;
            --inv-warning: #b45309;
            --inv-warning-soft: #fffbeb;
            --inv-danger: #b91c1c;
            --inv-danger-soft: #fef2f2;
            --inv-shadow: 0 16px 40px rgba(15, 23, 42, 0.06);
            --inv-radius-xl: 24px;
            --inv-radius-lg: 18px;
            --inv-radius-md: 14px;
        }

        .inventory-page{
            min-height: 100vh;
            padding: 24px 0 48px;
        }

        .inventory-shell{
            max-width: 1380px;
            margin: 0 auto;
            padding: 0 16px;
        }

        .inventory-stack{
            display: flex;
            flex-direction: column;
            gap: 22px;
        }

        .inventory-metrics{
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
        }

        .metric-card{
            background: var(--inv-panel);
            border: 1px solid var(--inv-line-soft);
            border-radius: 22px;
            box-shadow: var(--inv-shadow);
            padding: 20px;
        }

        .metric-label{
            font-size: .78rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .08em;
            color: var(--inv-muted);
            margin-bottom: 10px;
        }

        .metric-value{
            font-size: 2rem;
            line-height: 1;
            font-weight: 900;
            color: var(--inv-text);
        }

        .metric-sub{
            margin-top: 8px;
            font-size: .88rem;
            color: var(--inv-muted);
        }

        .metric-card.is-alert .metric-value{
            color: var(--inv-danger);
        }

        .metric-card.is-good .metric-value{
            color: var(--inv-success);
        }

        .toolbar-card{
            background: linear-gradient(135deg, #ffffff 0%, #f8fbff 100%);
            border: 1px solid var(--inv-line-soft);
            border-radius: 24px;
            box-shadow: var(--inv-shadow);
            padding: 18px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            flex-wrap: wrap;
        }

        .toolbar-title{
            margin: 0;
            font-size: 1.15rem;
            font-weight: 900;
            color: var(--inv-text);
        }

        .toolbar-text{
            margin: 6px 0 0;
            font-size: .92rem;
            color: var(--inv-muted);
        }

        .inventory-tabs{
            display: inline-flex;
            gap: 8px;
            background: #f1f5f9;
            border-radius: 999px;
            padding: 6px;
        }

        .inventory-tab{
            border: 0;
            background: transparent;
            color: #475569;
            padding: 10px 16px;
            border-radius: 999px;
            font-size: .88rem;
            font-weight: 800;
            cursor: pointer;
            transition: .18s ease;
        }

        .inventory-tab.is-active{
            background: #ffffff;
            color: var(--inv-text);
            box-shadow: 0 4px 10px rgba(15,23,42,.08);
        }

        .inventory-action{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 15px;
            border-radius: 999px;
            background: #16a34a;
            color: #ffffff;
            text-decoration: none;
            font-size: .88rem;
            font-weight: 800;
            box-shadow: 0 12px 24px rgba(22, 163, 74, .18);
            transition: .18s ease;
        }

        .inventory-action:hover{
            background: #15803d;
            transform: translateY(-1px);
        }

        .panel{
            background: var(--inv-panel);
            border: 1px solid var(--inv-line-soft);
            border-radius: var(--inv-radius-xl);
            box-shadow: var(--inv-shadow);
            overflow: hidden;
        }

        .panel-head{
            padding: 20px 22px 16px;
            border-bottom: 1px solid var(--inv-line-soft);
            background: linear-gradient(180deg, #ffffff 0%, #fbfdff 100%);
        }

        .panel-title{
            margin: 0;
            font-size: 1.08rem;
            font-weight: 900;
            color: var(--inv-text);
        }

        .panel-text{
            margin: 8px 0 0;
            font-size: .9rem;
            line-height: 1.6;
            color: var(--inv-muted);
        }

        .panel-text strong{
            color: var(--inv-text);
        }

        .panel-body{
            padding: 18px 22px 22px;
        }

        .table-wrap{
            overflow: auto;
            border: 1px solid var(--inv-line);
            border-radius: 18px;
            background: #fff;
        }

        .table-wrap::-webkit-scrollbar{
            width: 8px;
            height: 8px;
        }

        .table-wrap::-webkit-scrollbar-thumb{
            background: #cbd5e1;
            border-radius: 999px;
        }

        .inventory-table{
            width: 100%;
            min-width: 940px;
            border-collapse: collapse;
        }

        .inventory-table thead th{
            background: #f8fafc;
            color: #475569;
            font-size: .72rem;
            text-transform: uppercase;
            letter-spacing: .07em;
            font-weight: 900;
            text-align: left;
            padding: 13px 14px;
            border-bottom: 1px solid var(--inv-line-soft);
            position: sticky;
            top: 0;
            z-index: 2;
            white-space: nowrap;
        }

        .inventory-table tbody td{
            padding: 14px;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
            font-size: .9rem;
            vertical-align: middle;
        }

        .inventory-table tbody tr:hover{
            background: #fafcff;
        }

        .cell-main{
            font-weight: 800;
            color: var(--inv-text);
        }

        .cell-sub{
            display: block;
            margin-top: 4px;
            font-size: .76rem;
            color: var(--inv-muted);
        }

        .stock-pill{
            display: inline-flex;
            align-items: center;
            padding: 7px 10px;
            border-radius: 999px;
            font-size: .78rem;
            font-weight: 800;
            border: 1px solid transparent;
            white-space: nowrap;
        }

        .stock-pill.is-primary{
            background: var(--inv-primary-soft);
            color: var(--inv-primary);
            border-color: #bfdbfe;
        }

        .stock-pill.is-success{
            background: var(--inv-success-soft);
            color: var(--inv-success);
            border-color: #bbf7d0;
        }

        .stock-pill.is-danger{
            background: var(--inv-danger-soft);
            color: var(--inv-danger);
            border-color: #fecaca;
        }

        .stock-pill.is-muted{
            background: #f1f5f9;
            color: #475569;
            border-color: #e2e8f0;
        }

        .bag-card{
            display: inline-flex;
            flex-direction: column;
            gap: 4px;
            min-width: 160px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 10px 12px;
        }

        .bag-card-strong{
            font-size: .92rem;
            font-weight: 800;
            color: var(--inv-text);
        }

        .bag-card-note{
            font-size: .76rem;
            color: var(--inv-muted);
        }

        .bag-card-total{
            margin-top: 4px;
            padding-top: 6px;
            border-top: 1px solid #dbeafe;
            font-size: .84rem;
            font-weight: 900;
            color: var(--inv-primary);
        }

        .inline-actions{
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .inline-link{
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 7px 10px;
            border-radius: 10px;
            text-decoration: none;
            font-size: .8rem;
            font-weight: 800;
            transition: .18s ease;
        }

        .inline-link.edit{
            background: #eef2ff;
            color: #4338ca;
        }

        .inline-link.edit:hover{
            background: #e0e7ff;
        }

        .inline-link.delete{
            background: #fef2f2;
            color: #b91c1c;
            border: 0;
            cursor: pointer;
        }

        .inline-link.delete:hover{
            background: #fee2e2;
        }

        .panel-footer{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            flex-wrap: wrap;
            padding: 16px 22px;
            border-top: 1px solid var(--inv-line-soft);
            font-size: .86rem;
            color: var(--inv-muted);
        }

        .empty-state{
            padding: 46px 18px;
            text-align: center;
            background: #fcfcfd;
        }

        .empty-state svg{
            width: 54px;
            height: 54px;
            color: #cbd5e1;
            margin-bottom: 12px;
        }

        .empty-title{
            font-size: 1.05rem;
            font-weight: 800;
            color: #475569;
        }

        .empty-text{
            margin-top: 6px;
            font-size: .9rem;
            color: var(--inv-muted);
            line-height: 1.6;
        }

        .empty-text a{
            color: var(--inv-primary);
            font-weight: 700;
            text-decoration: none;
        }

        .empty-action{
            margin-top: 16px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 15px;
            border-radius: 999px;
            background: #16a34a;
            color: #fff;
            text-decoration: none;
            font-size: .88rem;
            font-weight: 800;
        }

        .raw-highlight{
            margin-bottom: 14px;
            padding: 14px 16px;
            border-radius: 16px;
            background: #fffbeb;
            border: 1px solid #fde68a;
            color: #92400e;
            font-size: .88rem;
            line-height: 1.55;
        }

        @media (max-width: 960px){
            .inventory-metrics{
                grid-template-columns: 1fr;
            }
        }
    </style>

    <div class="inventory-page">
        <div class="inventory-shell">
            <div class="inventory-stack">

                <section class="inventory-metrics">
                    <div class="metric-card">
                        <div class="metric-label">Total Raw Feed Items</div>
                        <div class="metric-value"><?php echo e(isset($ingredients) ? $ingredients->total() : 0); ?></div>
                        <div class="metric-sub">ingredients and raw materials in catalog</div>
                    </div>

                    <div class="metric-card">
                        <div class="metric-label">Tracked Feed Types</div>
                        <div class="metric-value"><?php echo e(isset($inventories) ? $inventories->total() : 0); ?></div>
                        <div class="metric-sub">manufactured feed stock records</div>
                    </div>

                    <?php ($lowCount = $lowStockCount ?? 0); ?>
                    <div class="metric-card <?php echo e($lowCount > 0 ? 'is-alert' : 'is-good'); ?>">
                        <div class="metric-label">Low / No Stock Items</div>
                        <div class="metric-value"><?php echo e($lowCount); ?></div>
                        <div class="metric-sub">items needing closer inventory attention</div>
                    </div>
                </section>

                <section class="toolbar-card">
                    <div>
                        <h1 class="toolbar-title">Feed Inventory</h1>
                        <p class="toolbar-text">
                            Manufactured feed is tracked as finished stock, while <strong>raw feed items</strong> are the purchasing layer where bags, bag weight, and total kilograms matter most.
                        </p>
                    </div>

                    <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                        <div class="inventory-tabs">
                            <button id="tab-feed" class="inventory-tab">Feed Types Stock</button>
                            <button id="tab-ingredients" class="inventory-tab">Raw Feed Items</button>
                        </div>

                        <a id="btn-add-ingredient" href="<?php echo e(route('ingredients.create')); ?>" class="inventory-action" style="display:none;">
                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                            </svg>
                            Add Item
                        </a>
                    </div>
                </section>

                <section id="panel-feed" class="panel">
                    <div class="panel-head">
                        <h2 class="panel-title">Current Feed Stock (Manufactured)</h2>
                        <p class="panel-text">
                            This section is for finished feed already produced or on hand. It is fine to keep this stock view simple and operational.
                        </p>
                    </div>

                    <div class="panel-body">
                        <div class="table-wrap">
                            <table class="inventory-table">
                                <thead>
                                    <tr>
                                        <th>Feed Type</th>
                                        <th>Protein %</th>
                                        <th>Energy (kcal/kg)</th>
                                        <th>On-hand Stock</th>
                                        <th>Last Updated</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php ($ft = App\Models\FeedType::with('recipe.items.ingredient')->find($inv->feed_type_id)); ?>
                                        <?php ($isLow = (float)$inv->quantity <= 0); ?>

                                        <tr>
                                            <td>
                                                <span class="cell-main"><?php echo e($ft->name ?? $inv->feed_type_id); ?></span>
                                            </td>
                                            <td><?php echo e(number_format($ft->computed_protein_percent ?? 0, 2)); ?></td>
                                            <td><?php echo e(number_format($ft->computed_energy_kcal_per_kg ?? 0, 0)); ?></td>
                                            <td>
                                                <span class="stock-pill <?php echo e($isLow ? 'is-danger' : 'is-primary'); ?>">
                                                    <?php echo e(number_format($inv->quantity, 2)); ?> <?php echo e($inv->unit); ?>

                                                </span>
                                            </td>
                                            <td><?php echo e($inv->last_updated ? $inv->last_updated->format('Y-m-d') : '-'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="5">
                                                <div class="empty-state">
                                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                                                    </svg>
                                                    <div class="empty-title">No Manufactured Feed Stock Tracked</div>
                                                    <div class="empty-text">
                                                        To track stock, first ensure you have defined
                                                        <a href="<?php echo e(route('feed-types.index')); ?>">Feed Types</a>.
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <?php if($inventories->count()): ?>
                        <div class="panel-footer">
                            <div>
                                Showing <?php echo e($inventories->firstItem()); ?> to <?php echo e($inventories->lastItem()); ?> of <?php echo e($inventories->total()); ?> results
                            </div>
                            <?php if($inventories->hasPages()): ?>
                                <div>
                                    <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $inventories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </section>

                <section id="panel-ingredients" class="panel" style="display:none;">
                    <div class="panel-head">
                        <h2 class="panel-title">Raw Feed Items Catalog + On-hand Inventory</h2>
                        <p class="panel-text">
                            This is the purchasing and material control layer. Here, <strong>bags are the primary unit</strong>, while kilograms act as the converted total using each item’s bag weight.
                        </p>
                    </div>

                    <div class="panel-body">
                        <div class="raw-highlight">
                            Use this section to decide what to buy. The most important values here are:
                            <strong>bags on hand</strong>, <strong>bag weight</strong>, and <strong>total kilograms available</strong>.
                        </div>

                        <div class="table-wrap">
                            <table class="inventory-table">
                                <thead>
                                    <tr>
                                        <th>Feed Item</th>
                                        <th>Unit Cost (₵)</th>
                                        <th>Protein %</th>
                                        <th>Energy (kcal/kg)</th>
                                        <th>Bag Profile</th>
                                        <th>Bags in Stock</th>
                                        <th>Unit</th>
                                        <th>Last Stock Update</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php ($inv = $ingredientInventoryMap[$ing->id] ?? null); ?>
                                        <?php ($qty = $inv ? (float)$inv->quantity : 0); ?>
                                        <?php ($isLow = $qty <= 0); ?>

                                        <tr>
                                            <td>
                                                <span class="cell-main"><?php echo e($ing->name); ?></span>
                                            </td>
                                            <td>₵<?php echo e(number_format($ing->cost_per_unit, 2)); ?></td>
                                            <td><?php echo e($ing->protein_percentage ?? 'N/A'); ?></td>
                                            <td><?php echo e($ing->energy_kcal_per_kg ?? 'N/A'); ?></td>

                                            <td>
                                                <?php if($ing->unit === 'bag' || $ing->unit === 'bags'): ?>
                                                    <?php ($bagWeight = (float)($ing->bag_weight_kg ?? 0)); ?>
                                                    <?php ($bags = $inv ? (float)$inv->quantity : 0); ?>

                                                    <?php if($bagWeight > 0 && $bags > 0): ?>
                                                        <?php ($totalKg = $bagWeight * $bags); ?>
                                                        <div class="bag-card">
                                                            <span class="bag-card-strong"><?php echo e(number_format($bagWeight, 2)); ?> kg/bag</span>
                                                            <span class="bag-card-note">× <?php echo e(number_format($bags, 2)); ?> bags on hand</span>
                                                            <span class="bag-card-total"><?php echo e(number_format($totalKg, 2)); ?> kg total</span>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="bag-card">
                                                            <span class="bag-card-strong"><?php echo e(number_format($bagWeight, 2)); ?> kg/bag</span>
                                                            <span class="bag-card-note">No bag stock available yet</span>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="stock-pill is-muted">N/A</span>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <span class="stock-pill <?php echo e($isLow ? 'is-danger' : 'is-success'); ?>">
                                                    <?php echo e(number_format($qty, 2)); ?> bags
                                                </span>
                                            </td>

                                            <td>
                                                <span class="stock-pill is-muted"><?php echo e($ing->unit); ?></span>
                                            </td>

                                            <td><?php echo e($inv && $inv->last_updated ? $inv->last_updated->format('Y-m-d') : '-'); ?></td>

                                            <td>
                                                <div class="inline-actions">
                                                    <a href="<?php echo e(route('ingredients.edit', $ing)); ?>" class="inline-link edit">Edit</a>
                                                    <form method="POST" action="<?php echo e(route('ingredients.destroy', $ing)); ?>" class="inline" onsubmit="return confirm('Are you sure you want to delete the feed item: <?php echo e($ing->name); ?>?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="inline-link delete">Delete</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="9">
                                                <div class="empty-state">
                                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                                    </svg>
                                                    <div class="empty-title">No Raw Feed Items Defined</div>
                                                    <div class="empty-text">
                                                        You need to define raw ingredients before you can track purchasing and material inventory.
                                                    </div>
                                                    <a id="btn-add-ingredient-empty" href="<?php echo e(route('ingredients.create')); ?>" class="empty-action">
                                                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                                        </svg>
                                                        Add Raw Feed Item
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <?php if($ingredients->count()): ?>
                        <div class="panel-footer">
                            <div>
                                Showing <?php echo e($ingredients->firstItem()); ?> to <?php echo e($ingredients->lastItem()); ?> of <?php echo e($ingredients->total()); ?> results
                            </div>
                            <?php if($ingredients->hasPages()): ?>
                                <div>
                                    <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $ingredients]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ingredients)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </section>

            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal968de545b91fcc58d7756a37a6904e98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal968de545b91fcc58d7756a37a6904e98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.copyright-minimal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('copyright-minimal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $attributes = $__attributesOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__attributesOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $component = $__componentOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__componentOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const tabFeed = document.getElementById('tab-feed');
            const tabIng = document.getElementById('tab-ingredients');
            const panelFeed = document.getElementById('panel-feed');
            const panelIng = document.getElementById('panel-ingredients');
            const btnIngredient = document.getElementById('btn-add-ingredient');

            function activate(tab) {
                localStorage.setItem('activeInventoryTab', tab);

                const activeIsFeed = tab === 'feed';
                panelFeed.style.display = activeIsFeed ? 'block' : 'block';
                panelFeed.style.display = activeIsFeed ? 'block' : 'none';
                panelIng.style.display = activeIsFeed ? 'none' : 'block';

                tabFeed.classList.toggle('is-active', activeIsFeed);
                tabIng.classList.toggle('is-active', !activeIsFeed);

                if (btnIngredient) {
                    btnIngredient.style.display = activeIsFeed ? 'none' : 'inline-flex';
                }
            }

            const savedTab = localStorage.getItem('activeInventoryTab') || 'feed';
            activate(savedTab);

            tabFeed.addEventListener('click', () => activate('feed'));
            tabIng.addEventListener('click', () => activate('ingredients'));
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/charlotte/chipper-farms/resources/views/feeds/inventory.blade.php ENDPATH**/ ?>