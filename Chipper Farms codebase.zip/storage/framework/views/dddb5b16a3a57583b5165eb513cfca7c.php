<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <!-- Styles -->
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
    <body>
        <div class="font-sans text-gray-900 antialiased">
            <?php echo e($slot); ?>

        </div>

        <!-- Copyright Footer -->
        <!-- <?php if (isset($component)) { $__componentOriginal968de545b91fcc58d7756a37a6904e98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal968de545b91fcc58d7756a37a6904e98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.copyright-minimal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('copyright-minimal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $attributes = $__attributesOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__attributesOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $component = $__componentOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__componentOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?> -->

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    </body>
</html>
<?php /**PATH /home/charlotte/chipper-farms/resources/views/layouts/guest.blade.php ENDPATH**/ ?>