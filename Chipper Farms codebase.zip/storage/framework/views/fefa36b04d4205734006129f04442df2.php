<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination" class="flex items-center justify-between">
        
        <?php if($paginator->onFirstPage()): ?>
            <span class="inline-flex items-center px-4 py-2 bg-white text-gray-400 border border-gray-200 rounded-lg cursor-not-allowed">Previous</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="inline-flex items-center px-4 py-2 bg-white text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Previous</a>
        <?php endif; ?>

        
        <div class="flex items-center space-x-1">
            <?php
                $currentPage = $paginator->currentPage();
                $lastPage = $paginator->lastPage();
                $startPage = max(1, $currentPage - 2);
                $endPage = min($lastPage, $currentPage + 2);
            ?>

            
            <?php if($startPage > 1): ?>
                <a href="<?php echo e($paginator->url(1)); ?>" class="inline-flex items-center px-4 py-2 bg-white text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">1</a>
                <?php if($startPage > 2): ?>
                    <span class="px-3 py-2 text-gray-500">...</span>
                <?php endif; ?>
            <?php endif; ?>

            
            <?php for($page = $startPage; $page <= $endPage; $page++): ?>
                <?php if($page == $currentPage): ?>
                    <span class="inline-flex items-center px-4 py-2 bg-blue-600 text-white border border-blue-600 rounded-lg font-medium"><?php echo e($page); ?></span>
                <?php else: ?>
                    <a href="<?php echo e($paginator->url($page)); ?>" class="inline-flex items-center px-4 py-2 bg-white text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50"><?php echo e($page); ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            
            <?php if($endPage < $lastPage): ?>
                <?php if($endPage < $lastPage - 1): ?>
                    <span class="px-3 py-2 text-gray-500">...</span>
                <?php endif; ?>
                <a href="<?php echo e($paginator->url($lastPage)); ?>" class="inline-flex items-center px-4 py-2 bg-white text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50"><?php echo e($lastPage); ?></a>
            <?php endif; ?>
        </div>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="inline-flex items-center px-4 py-2 bg-white text-gray-700 border border-gray-200 rounded-lg hover:bg-gray-50">Next</a>
        <?php else: ?>
            <span class="inline-flex items-center px-4 py-2 bg-white text-gray-400 border border-gray-200 rounded-lg cursor-not-allowed">Next</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>


<?php /**PATH /home/charlotte/chipper-farms/resources/views/components/simple-pagination.blade.php ENDPATH**/ ?>