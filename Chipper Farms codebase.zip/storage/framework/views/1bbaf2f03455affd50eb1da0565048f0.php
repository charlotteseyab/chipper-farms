<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-slate-900">Purchase Requests</h1>
                    <p class="text-sm text-slate-600">Track requests for feed raw materials.</p>
                </div>

                <button
                    type="button"
                    onclick="document.getElementById('purchaseRequestForm').classList.toggle('hidden')"
                    class="inline-flex items-center px-4 py-2 rounded-xl bg-[#218c6a] text-white text-sm font-medium hover:opacity-90 transition"
                >
                    New Request
                </button>
            </div>

            <?php if(session('success')): ?>
                <div class="mb-4 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-green-700 text-sm">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-red-700 text-sm">
                    <ul class="list-disc pl-5 space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div id="purchaseRequestForm" class="hidden bg-white rounded-2xl border shadow-sm p-6 mb-6">
                <h2 class="text-lg font-semibold text-slate-900 mb-4">Create Purchase Request</h2>

                <form action="<?php echo e(route('feed-management.purchase-requests.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Request Date</label>
                            <input
                                type="date"
                                name="request_date"
                                value="<?php echo e(old('request_date', now()->format('Y-m-d'))); ?>"
                                class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                required
                            >
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Supplier</label>
                            <select
                                name="supplier_id"
                                class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                            >
                                <option value="">Select supplier</option>
                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($supplier->id); ?>" <?php if(old('supplier_id') == $supplier->id): echo 'selected'; endif; ?>>
                                        <?php echo e($supplier->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
                            <input
                                type="text"
                                value="Pending"
                                class="w-full rounded-xl border-slate-300 bg-slate-100"
                                readonly
                            >
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-medium text-slate-700 mb-1">Remarks</label>
                        <textarea
                            name="remarks"
                            rows="3"
                            class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                            placeholder="Optional notes about this request"
                        ><?php echo e(old('remarks')); ?></textarea>
                    </div>

                    <div class="border rounded-2xl overflow-hidden mb-4">
                        <div class="bg-slate-50 px-4 py-3 border-b">
                            <h3 class="text-sm font-semibold text-slate-800">Request Items</h3>
                        </div>

                        <div class="p-4 space-y-4">
                            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-1">Raw Material</label>
                                    <select
                                        name="items[0][raw_material_id]"
                                        class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                        required
                                    >
                                        <option value="">Select material</option>
                                        <?php $__currentLoopData = $rawMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($material->id); ?>">
                                                <?php echo e($material->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-1">Quantity Requested</label>
                                    <input
                                        type="number"
                                        step="0.01"
                                        name="items[0][quantity_requested]"
                                        class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                        required
                                    >
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-1">Unit Price</label>
                                    <input
                                        type="number"
                                        step="0.01"
                                        name="items[0][unit_price]"
                                        class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                    >
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-1">Remarks</label>
                                    <input
                                        type="text"
                                        name="items[0][remarks]"
                                        class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                        placeholder="Optional"
                                    >
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center gap-3">
                        <button
                            type="submit"
                            class="inline-flex items-center px-4 py-2 rounded-xl bg-[#218c6a] text-white text-sm font-medium hover:opacity-90 transition"
                        >
                            Save Request
                        </button>

                        <button
                            type="button"
                            onclick="document.getElementById('purchaseRequestForm').classList.add('hidden')"
                            class="inline-flex items-center px-4 py-2 rounded-xl border text-sm font-medium text-slate-700 hover:bg-slate-50 transition"
                        >
                            Cancel
                        </button>
                    </div>
                </form>
            </div>

            <div class="bg-white rounded-2xl border shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-4 py-3 text-left">Request No</th>
                                <th class="px-4 py-3 text-left">Date</th>
                                <th class="px-4 py-3 text-left">Supplier</th>
                                <th class="px-4 py-3 text-left">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $purchaseRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-t">
                                    <td class="px-4 py-3 font-medium"><?php echo e($request->request_no); ?></td>
                                    <td class="px-4 py-3"><?php echo e(optional($request->request_date)->format('d M Y')); ?></td>
                                    <td class="px-4 py-3"><?php echo e($request->supplier->name ?? '—'); ?></td>
                                    <td class="px-4 py-3"><?php echo e(ucfirst(str_replace('_', ' ', $request->status))); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="px-4 py-6 text-center text-slate-500">No purchase requests found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="p-4">
                    <?php echo e($purchaseRequests->links()); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/charlotte/chipper-farms/resources/views/feed-management/purchase-requests.blade.php ENDPATH**/ ?>