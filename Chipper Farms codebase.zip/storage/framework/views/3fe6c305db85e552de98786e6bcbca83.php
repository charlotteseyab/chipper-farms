<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $statusClasses = [
            'in_stock' => 'bg-green-100 text-green-800 border border-green-200',
            'low_stock' => 'bg-amber-100 text-amber-800 border border-amber-200',
            'out_of_stock' => 'bg-red-100 text-red-800 border border-red-200',
        ];
    ?>

    <div class="max-w-7xl mx-auto py-6 px-4" x-data="{ openModal: null, selectedMaterial: null }">
        <div class="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">Raw Materials & Stock</h1>
                <p class="text-sm text-gray-500">Manage raw materials, stock levels, receiving, and adjustments.</p>
            </div>

            <button type="button"
                    @click="openModal = 'add'"
                    class="inline-flex items-center justify-center px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white text-sm font-semibold rounded-xl shadow-sm transition">
                + Add Raw Material
            </button>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
            <div class="rounded-2xl border border-slate-100 bg-white shadow-sm p-5">
                <p class="text-sm font-medium text-gray-500">Total Materials</p>
                <h3 class="mt-2 text-3xl font-bold text-slate-800"><?php echo e($stats['total_materials'] ?? 0); ?></h3>
                <p class="mt-1 text-xs text-gray-400">All raw materials in store</p>
            </div>

            <div class="rounded-2xl border border-amber-100 bg-white shadow-sm p-5">
                <p class="text-sm font-medium text-gray-500">Low Stock</p>
                <h3 class="mt-2 text-3xl font-bold text-amber-700"><?php echo e($stats['low_stock'] ?? 0); ?></h3>
                <p class="mt-1 text-xs text-gray-400">Materials at or below reorder level</p>
            </div>

            <div class="rounded-2xl border border-red-100 bg-white shadow-sm p-5">
                <p class="text-sm font-medium text-gray-500">Out of Stock</p>
                <h3 class="mt-2 text-3xl font-bold text-red-700"><?php echo e($stats['out_of_stock'] ?? 0); ?></h3>
                <p class="mt-1 text-xs text-gray-400">Materials with zero balance</p>
            </div>

            <div class="rounded-2xl border border-emerald-100 bg-white shadow-sm p-5">
                <p class="text-sm font-medium text-gray-500">Total Stock Value</p>
                <h3 class="mt-2 text-3xl font-bold text-emerald-700"><?php echo e(number_format($stats['stock_value'] ?? 0, 2)); ?></h3>
                <p class="mt-1 text-xs text-gray-400">Estimated inventory value</p>
            </div>
        </div>

        <?php if(($lowStockAlerts ?? collect())->count()): ?>
            <div class="mb-6 overflow-hidden rounded-2xl border border-amber-200 bg-amber-50 shadow-sm">
                <div class="border-b border-amber-200 px-6 py-4">
                    <div class="flex items-center justify-between gap-3">
                        <div>
                            <h2 class="text-base font-semibold text-amber-900">Low Stock Alerts</h2>
                            <p class="mt-1 text-sm text-amber-700">
                                These materials need attention because stock is low or exhausted.
                            </p>
                        </div>

                        <span class="inline-flex items-center rounded-full bg-white px-3 py-1 text-xs font-semibold text-amber-800 border border-amber-200">
                            <?php echo e($lowStockAlerts->count()); ?> item<?php echo e($lowStockAlerts->count() > 1 ? 's' : ''); ?>

                        </span>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 p-6">
                    <?php $__currentLoopData = $lowStockAlerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isOut = (float) $alert->quantity_in_stock <= 0;
                        ?>

                        <div class="rounded-xl border <?php echo e($isOut ? 'border-red-200 bg-red-50' : 'border-amber-200 bg-white'); ?> p-4">
                            <div class="flex items-start justify-between gap-3">
                                <div>
                                    <h3 class="text-sm font-semibold text-gray-900"><?php echo e($alert->name); ?></h3>
                                    <p class="mt-1 text-xs text-gray-500">
                                        <?php echo e($alert->category ?: 'No category'); ?> • Unit: <?php echo e($alert->unit); ?>

                                    </p>
                                </div>

                                <span class="inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold <?php echo e($isOut ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'); ?>">
                                    <?php echo e($isOut ? 'Out of Stock' : 'Low Stock'); ?>

                                </span>
                            </div>

                            <div class="mt-4 grid grid-cols-2 gap-3 text-sm">
                                <div class="rounded-lg bg-white/80 px-3 py-2 border border-gray-100">
                                    <p class="text-gray-500">Available</p>
                                    <p class="font-semibold text-gray-800">
                                        <?php echo e(number_format($alert->quantity_in_stock, 2)); ?> <?php echo e($alert->unit); ?>

                                    </p>
                                </div>

                                <div class="rounded-lg bg-white/80 px-3 py-2 border border-gray-100">
                                    <p class="text-gray-500">Reorder Level</p>
                                    <p class="font-semibold text-gray-800">
                                        <?php echo e(number_format($alert->reorder_level, 2)); ?> <?php echo e($alert->unit); ?>

                                    </p>
                                </div>
                            </div>

                            <div class="mt-4 flex flex-wrap gap-2">
                                <button type="button"
                                        @click='selectedMaterial = <?php echo json_encode($alert, 15, 512) ?>; openModal = "receive"'
                                        class="inline-flex items-center rounded-lg bg-green-600 px-3 py-1.5 text-sm font-semibold text-white hover:bg-green-700 transition">
                                    Receive Stock
                                </button>

                                <button type="button"
                                        @click='selectedMaterial = <?php echo json_encode($alert, 15, 512) ?>; openModal = "adjust"'
                                        class="inline-flex items-center rounded-lg bg-white px-3 py-1.5 text-sm font-semibold text-amber-700 border border-amber-200 hover:bg-amber-100 transition">
                                    Adjust Stock
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

        <form method="GET" action="<?php echo e(route('raw-materials.index')); ?>" class="mb-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                    <input type="text"
                           name="search"
                           value="<?php echo e($search); ?>"
                           placeholder="Search by name, category or unit"
                           class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Stock Status</label>
                    <select name="status"
                            class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        <option value="">All Statuses</option>
                        <option value="in_stock" <?php echo e($status === 'in_stock' ? 'selected' : ''); ?>>In Stock</option>
                        <option value="low_stock" <?php echo e($status === 'low_stock' ? 'selected' : ''); ?>>Low Stock</option>
                        <option value="out_of_stock" <?php echo e($status === 'out_of_stock' ? 'selected' : ''); ?>>Out of Stock</option>
                    </select>
                </div>

                <div class="flex items-end gap-3">
                    <button type="submit"
                            class="inline-flex items-center justify-center px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white text-sm font-semibold rounded-xl shadow-sm transition">
                        Filter
                    </button>

                    <a href="<?php echo e(route('raw-materials.index')); ?>"
                       class="inline-flex items-center justify-center px-4 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-800 text-sm font-semibold rounded-xl transition">
                        Reset
                    </a>
                </div>
            </div>
        </form>

        <div class="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
            <div class="border-b border-gray-100 px-6 py-4">
                <h2 class="text-base font-semibold text-gray-800">Raw Materials Inventory</h2>
                <p class="text-sm text-gray-500 mt-1">Monitor available stock, unit cost, reorder level, and stock actions.</p>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-100">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Material</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Category</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Unit</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Quantity</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Unit Cost</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Reorder Level</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Stock Value</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Status</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Actions</th>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-gray-100 bg-white">
                        <?php $__empty_1 = true; $__currentLoopData = $rawMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $materialStatus = $material->stock_status;
                            ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-6 py-4">
                                    <div class="font-semibold text-gray-800"><?php echo e($material->name); ?></div>
                                    <?php if($material->notes): ?>
                                        <div class="text-xs text-gray-400 mt-1 line-clamp-1"><?php echo e($material->notes); ?></div>
                                    <?php endif; ?>
                                </td>

                                <td class="px-6 py-4 text-sm text-gray-700">
                                    <?php echo e($material->category ?: '—'); ?>

                                </td>

                                <td class="px-6 py-4 text-sm text-gray-700">
                                    <?php echo e($material->unit); ?>

                                </td>

                                <td class="px-6 py-4 text-sm font-semibold text-gray-800">
                                    <?php echo e(number_format($material->quantity_in_stock, 2)); ?>

                                </td>

                                <td class="px-6 py-4 text-sm text-gray-700">
                                    <?php echo e(number_format($material->unit_cost, 2)); ?>

                                </td>

                                <td class="px-6 py-4 text-sm text-gray-700">
                                    <?php echo e(number_format($material->reorder_level, 2)); ?>

                                </td>

                                <td class="px-6 py-4 text-sm font-semibold text-gray-800">
                                    <?php echo e(number_format($material->stock_value, 2)); ?>

                                </td>

                                <td class="px-6 py-4">
                                    <span class="inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold <?php echo e($statusClasses[$materialStatus] ?? 'bg-gray-100 text-gray-700 border border-gray-200'); ?>">
                                        <?php echo e(ucfirst(str_replace('_', ' ', $materialStatus))); ?>

                                    </span>
                                </td>

                                <td class="px-6 py-4">
                                    <div class="flex flex-wrap gap-2">
                                        <button type="button"
                                                @click='selectedMaterial = <?php echo json_encode($material, 15, 512) ?>; openModal = "edit"'
                                                class="inline-flex items-center rounded-lg bg-blue-50 px-3 py-1.5 text-sm font-semibold text-blue-700 hover:bg-blue-100 transition">
                                            Edit
                                        </button>

                                        <button type="button"
                                                @click='selectedMaterial = <?php echo json_encode($material, 15, 512) ?>; openModal = "receive"'
                                                class="inline-flex items-center rounded-lg bg-green-50 px-3 py-1.5 text-sm font-semibold text-green-700 hover:bg-green-100 transition">
                                            Receive
                                        </button>

                                        <button type="button"
                                                @click='selectedMaterial = <?php echo json_encode($material, 15, 512) ?>; openModal = "adjust"'
                                                class="inline-flex items-center rounded-lg bg-amber-50 px-3 py-1.5 text-sm font-semibold text-amber-700 hover:bg-amber-100 transition">
                                            Adjust
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="px-6 py-12 text-center">
                                    <div class="flex flex-col items-center justify-center">
                                        <div class="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-gray-100 text-gray-400">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V7a2 2 0 00-2-2h-3V3H9v2H6a2 2 0 00-2 2v6m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0H4" />
                                            </svg>
                                        </div>
                                        <h3 class="text-base font-semibold text-gray-700">No raw materials found</h3>
                                        <p class="mt-1 text-sm text-gray-500">Add your first raw material to begin inventory tracking.</p>
                                        <button type="button"
                                                @click="openModal = 'add'"
                                                class="mt-4 inline-flex items-center rounded-xl bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-700 transition">
                                            + Add Raw Material
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-5">
            <?php echo e($rawMaterials->links()); ?>

        </div>

        <?php if(($recentStockActivities ?? collect())->count()): ?>
            <div class="mt-6 overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
                <div class="border-b border-gray-100 px-6 py-4">
                    <h2 class="text-base font-semibold text-gray-800">Recent Stock Activity</h2>
                    <p class="text-sm text-gray-500 mt-1">Latest receiving and adjustment actions on raw materials.</p>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-100">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Material</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Activity Type</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Quantity</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Unit Cost</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Reference</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Performed By</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Date</th>
                            </tr>
                        </thead>

                        <tbody class="divide-y divide-gray-100 bg-white">
                            <?php $__currentLoopData = $recentStockActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $typeClasses = match($activity->type) {
                                        'receive' => 'bg-green-100 text-green-800 border border-green-200',
                                        'adjustment' => 'bg-amber-100 text-amber-800 border border-amber-200',
                                        'usage' => 'bg-blue-100 text-blue-800 border border-blue-200',
                                        default => 'bg-gray-100 text-gray-700 border border-gray-200',
                                    };
                                ?>

                                <tr class="hover:bg-gray-50 transition">
                                    <td class="px-6 py-4">
                                        <div class="font-semibold text-gray-800"><?php echo e($activity->rawMaterial->name ?? '—'); ?></div>
                                    </td>

                                    <td class="px-6 py-4">
                                        <span class="inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold <?php echo e($typeClasses); ?>">
                                            <?php echo e(ucfirst($activity->type)); ?>

                                        </span>
                                    </td>

                                    <td class="px-6 py-4 text-sm font-semibold text-gray-800">
                                        <?php echo e(number_format($activity->quantity, 2)); ?>

                                    </td>

                                    <td class="px-6 py-4 text-sm text-gray-700">
                                        <?php echo e($activity->unit_cost !== null ? number_format($activity->unit_cost, 2) : '—'); ?>

                                    </td>

                                    <td class="px-6 py-4 text-sm text-gray-700">
                                        <?php echo e($activity->reference ?: '—'); ?>

                                    </td>

                                    <td class="px-6 py-4 text-sm text-gray-700">
                                        <?php echo e(trim(($activity->performer->first_name ?? '') . ' ' . ($activity->performer->last_name ?? '')) ?: ($activity->performer->name ?? 'System')); ?>

                                    </td>

                                    <td class="px-6 py-4 text-sm text-gray-600">
                                        <?php echo e(optional($activity->created_at)->format('M d, Y h:i A')); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="px-6 py-4 border-t border-gray-100">
                    <?php echo e($recentStockActivities->links()); ?>

                </div>
            </div>
        <?php endif; ?>

        <!-- Add Modal -->
        <div x-show="openModal === 'add'" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
            <div @click.away="openModal = null" class="w-full max-w-2xl rounded-2xl bg-white shadow-2xl overflow-hidden">
                <div class="flex items-center justify-between border-b border-gray-100 px-6 py-4">
                    <h3 class="text-lg font-semibold text-gray-800">Add Raw Material</h3>
                    <button type="button" @click="openModal = null" class="text-gray-400 hover:text-gray-600 text-xl">&times;</button>
                </div>

                <form action="<?php echo e(route('raw-materials.store')); ?>" method="POST" class="p-6 space-y-5">
                    <?php echo csrf_field(); ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Material Name</label>
                            <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" required>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                            <input type="text" name="category" value="<?php echo e(old('category')); ?>"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Unit</label>
                            <input type="text" name="unit" value="<?php echo e(old('unit', 'kg')); ?>"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" required>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Opening Stock</label>
                            <input type="number" step="0.01" min="0" name="quantity_in_stock" value="<?php echo e(old('quantity_in_stock', 0)); ?>"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Unit Cost</label>
                            <input type="number" step="0.01" min="0" name="unit_cost" value="<?php echo e(old('unit_cost', 0)); ?>"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Reorder Level</label>
                            <input type="number" step="0.01" min="0" name="reorder_level" value="<?php echo e(old('reorder_level', 0)); ?>"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                            <textarea name="notes" rows="3"
                                      class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"><?php echo e(old('notes')); ?></textarea>
                        </div>
                    </div>

                    <div class="flex justify-end gap-3 pt-2">
                        <button type="button" @click="openModal = null"
                                class="px-4 py-2.5 rounded-xl bg-gray-200 hover:bg-gray-300 text-sm font-semibold text-gray-800 transition">
                            Cancel
                        </button>
                        <button type="submit"
                                class="px-4 py-2.5 rounded-xl bg-green-600 hover:bg-green-700 text-sm font-semibold text-white transition">
                            Save Material
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Edit Modal -->
        <div x-show="openModal === 'edit' && selectedMaterial" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
            <div @click.away="openModal = null" class="w-full max-w-2xl rounded-2xl bg-white shadow-2xl overflow-hidden">
                <div class="flex items-center justify-between border-b border-gray-100 px-6 py-4">
                    <h3 class="text-lg font-semibold text-gray-800">Edit Raw Material</h3>
                    <button type="button" @click="openModal = null" class="text-gray-400 hover:text-gray-600 text-xl">&times;</button>
                </div>

                <form :action="`/raw-materials-stock/${selectedMaterial.id}`" method="POST" class="p-6 space-y-5">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Material Name</label>
                            <input type="text" name="name" :value="selectedMaterial.name"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" required>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                            <input type="text" name="category" :value="selectedMaterial.category"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Unit</label>
                            <input type="text" name="unit" :value="selectedMaterial.unit"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" required>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Unit Cost</label>
                            <input type="number" step="0.01" min="0" name="unit_cost" :value="selectedMaterial.unit_cost"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Reorder Level</label>
                            <input type="number" step="0.01" min="0" name="reorder_level" :value="selectedMaterial.reorder_level"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                            <textarea name="notes" rows="3"
                                      class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                                      x-text="selectedMaterial.notes"></textarea>
                        </div>
                    </div>

                    <div class="flex justify-end gap-3 pt-2">
                        <button type="button" @click="openModal = null"
                                class="px-4 py-2.5 rounded-xl bg-gray-200 hover:bg-gray-300 text-sm font-semibold text-gray-800 transition">
                            Cancel
                        </button>
                        <button type="submit"
                                class="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-sm font-semibold text-white transition">
                            Update Material
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Receive Modal -->
        <div x-show="openModal === 'receive' && selectedMaterial" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
            <div @click.away="openModal = null" class="w-full max-w-xl rounded-2xl bg-white shadow-2xl overflow-hidden">
                <div class="flex items-center justify-between border-b border-gray-100 px-6 py-4">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Receive Stock</h3>
                        <p class="text-sm text-gray-500" x-text="selectedMaterial ? selectedMaterial.name : ''"></p>
                    </div>
                    <button type="button" @click="openModal = null" class="text-gray-400 hover:text-gray-600 text-xl">&times;</button>
                </div>

                <form :action="`/raw-materials-stock/${selectedMaterial.id}/receive`" method="POST" class="p-6 space-y-5">
                    <?php echo csrf_field(); ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Quantity Received</label>
                            <input type="number" step="0.01" min="0.01" name="quantity"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" required>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Unit Cost</label>
                            <input type="number" step="0.01" min="0" name="unit_cost" :value="selectedMaterial.unit_cost"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Reference</label>
                            <input type="text" name="reference" placeholder="e.g. Invoice No / GRN"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500">
                        </div>

                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                            <textarea name="notes" rows="3"
                                      class="w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"></textarea>
                        </div>
                    </div>

                    <div class="flex justify-end gap-3 pt-2">
                        <button type="button" @click="openModal = null"
                                class="px-4 py-2.5 rounded-xl bg-gray-200 hover:bg-gray-300 text-sm font-semibold text-gray-800 transition">
                            Cancel
                        </button>
                        <button type="submit"
                                class="px-4 py-2.5 rounded-xl bg-green-600 hover:bg-green-700 text-sm font-semibold text-white transition">
                            Receive Stock
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Adjust Modal -->
        <div x-show="openModal === 'adjust' && selectedMaterial" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
            <div @click.away="openModal = null" class="w-full max-w-xl rounded-2xl bg-white shadow-2xl overflow-hidden">
                <div class="flex items-center justify-between border-b border-gray-100 px-6 py-4">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">Adjust Stock</h3>
                        <p class="text-sm text-gray-500" x-text="selectedMaterial ? selectedMaterial.name : ''"></p>
                    </div>
                    <button type="button" @click="openModal = null" class="text-gray-400 hover:text-gray-600 text-xl">&times;</button>
                </div>

                <form :action="`/raw-materials-stock/${selectedMaterial.id}/adjust`" method="POST" class="p-6 space-y-5">
                    <?php echo csrf_field(); ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Adjustment Type</label>
                            <select name="adjustment_type"
                                    class="w-full rounded-xl border-gray-300 shadow-sm focus:border-amber-500 focus:ring-amber-500" required>
                                <option value="add">Add to Stock</option>
                                <option value="deduct">Deduct from Stock</option>
                                <option value="set">Set Exact Stock</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Quantity</label>
                            <input type="number" step="0.01" min="0.01" name="quantity"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-amber-500 focus:ring-amber-500" required>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Reference</label>
                            <input type="text" name="reference" placeholder="e.g. Stock Count / Correction"
                                   class="w-full rounded-xl border-gray-300 shadow-sm focus:border-amber-500 focus:ring-amber-500">
                        </div>

                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                            <textarea name="notes" rows="3"
                                      class="w-full rounded-xl border-gray-300 shadow-sm focus:border-amber-500 focus:ring-amber-500"></textarea>
                        </div>
                    </div>

                    <div class="flex justify-end gap-3 pt-2">
                        <button type="button" @click="openModal = null"
                                class="px-4 py-2.5 rounded-xl bg-gray-200 hover:bg-gray-300 text-sm font-semibold text-gray-800 transition">
                            Cancel
                        </button>
                        <button type="submit"
                                class="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-sm font-semibold text-white transition">
                            Save Adjustment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <style>
        [x-cloak] { display: none !important; }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/charlotte/chipper-farms/resources/views/feeds/raw-materials/index.blade.php ENDPATH**/ ?>