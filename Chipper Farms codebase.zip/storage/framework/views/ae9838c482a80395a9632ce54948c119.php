<a href="/">
    <img src="/images/chipper-farms-logo.jpg" alt="Chipper Farms Logo" class="h-10 w-auto" />
</a>
<?php /**PATH /home/charlotte/chipper-farms/resources/views/components/application-logo.blade.php ENDPATH**/ ?>