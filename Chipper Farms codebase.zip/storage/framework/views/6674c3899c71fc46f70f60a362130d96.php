<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="container mx-auto px-4 py-2">
    <!-- Header -->
    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-3xl font-bold text-gray-900">Weaning Management</h1>
            <p class="text-gray-600 mt-2">Track litters by mother's ear tag - from birth to maturity</p>
        </div>
        <div class="flex gap-3">
            <a href="<?php echo e(route('all-stocks.index')); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                <svg class="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
                View All Stock
            </a>
        </div>
    </div>

    <!-- Stats Overview -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white p-6 rounded-xl shadow border-l-4 border-red-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Ready Now</p>
                    <p class="text-3xl font-bold text-red-600"><?php echo e($stats['ready_now']); ?><span class="text-lg font-normal text-gray-700"> litter(s)</span></p>
                    <p class="text-xs text-gray-500"><?php echo e($stats['ready_now_total']); ?> piglets (<?php echo e($stats['overdue_count']); ?> overdue)</p>
                </div>
                <div class="p-3 bg-red-100 rounded-full">
                    <svg class="h-6 w-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/>
                    </svg>
                </div>
            </div>
        </div>
        
        <div class="bg-white p-6 rounded-xl shadow border-l-4 border-yellow-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Due Soon</p>
                    <p class="text-3xl font-bold text-yellow-600"><?php echo e($stats['due_soon']); ?><span class="text-lg font-normal text-gray-700"> litter(s)</span></p>
                    <p class="text-xs text-gray-500"><?php echo e($stats['due_soon_total']); ?> piglets (Next 7 days)</p>
                </div>
                <div class="p-3 bg-yellow-100 rounded-full">
                    <svg class="h-6 w-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
            </div>
        </div>
        
        <!-- <div class="bg-white p-6 rounded-xl shadow border-l-4 border-blue-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">In Progress</p>
                    <p class="text-3xl font-bold text-blue-600"><?php echo e($stats['in_progress']); ?></p>
                    <p class="text-xs text-gray-500">Weaned, growing</p>
                </div>
                <div class="p-3 bg-blue-100 rounded-full">
                    <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                    </svg>
                </div>
            </div>
        </div> -->
        
        <!-- <div class="bg-white p-6 rounded-xl shadow border-l-4 border-green-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Completed</p>
                    <p class="text-3xl font-bold text-green-600"><?php echo e($stats['completed_total']); ?></p>
                    <p class="text-xs text-gray-500"><?php echo e($stats['completed_this_month']); ?> this month</p>
                </div>
                <div class="p-3 bg-green-100 rounded-full">
                    <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
            </div>
        </div> -->
    </div>

    <!-- Tabbed Interface -->
    <div class="bg-white rounded-xl shadow" x-data="{ activeTab: 'ready' }">
        <!-- Tab Navigation -->
        <div class="border-b border-gray-200">
            <nav class="flex space-x-8 px-6" aria-label="Tabs">
            <button @click="activeTab = 'soon'" :class="activeTab === 'soon' ? 'border-yellow-500 text-yellow-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'" class="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    Due Soon (<?php echo e($stats['due_soon']); ?>)
                </button>
                <button @click="activeTab = 'ready'" :class="activeTab === 'ready' ? 'border-red-500 text-red-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'" class="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    Ready Now (<?php echo e($stats['ready_now']); ?>)
                </button>
                <!-- <button @click="activeTab = 'progress'" :class="activeTab === 'progress' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'" class="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    In Progress (<?php echo e($stats['in_progress']); ?>)
                </button>
                <button @click="activeTab = 'completed'" :class="activeTab === 'completed' ? 'border-green-500 text-green-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'" class="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    Completed (<?php echo e($stats['completed_total']); ?>)
                </button> -->
            </nav>
        </div>

        <!-- Tab Content -->
        <div class="p-6">
            <!-- READY NOW TAB -->
            <div x-show="activeTab === 'ready'" x-transition>
                <div class="mb-4">
                    <h3 class="text-lg font-semibold text-gray-900">Litters Ready for Weaning (<?php echo e($weaningAge); ?>+ days old)</h3>
                    <p class="text-sm text-gray-600">These litters can be weaned immediately. Track by mother's ear tag and litter size.</p>
                </div>
                
                <?php if($readyNowLitters->count() > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mother (Sow)</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Litter Age</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Surviving Piglets</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Farrowing Date</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__currentLoopData = $readyNowLitters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $litter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-gray-50 <?php if($litter->is_critical): ?> bg-red-50 <?php elseif($litter->is_overdue): ?> bg-orange-50 <?php else: ?> bg-green-50 <?php endif; ?>">
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="flex-shrink-0 h-10 w-10">
                                                    <div class="h-10 w-10 rounded-full <?php if($litter->is_critical): ?> bg-red-200 <?php elseif($litter->is_overdue): ?> bg-orange-200 <?php else: ?> bg-green-200 <?php endif; ?> flex items-center justify-center">
                                                        <span class="text-sm font-medium <?php if($litter->is_critical): ?> text-red-800 <?php elseif($litter->is_overdue): ?> text-orange-800 <?php else: ?> text-green-800 <?php endif; ?>">
                                                            🐷
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="ml-4">
                                                    <div class="text-sm font-medium text-gray-900"><?php echo e($litter->sow->ear_tag_number); ?></div>
                                                    <div class="text-xs text-gray-500"><?php echo e($litter->sow->code ?? 'N/A'); ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium <?php if($litter->is_critical): ?> text-red-600 <?php elseif($litter->is_overdue): ?> text-orange-600 <?php else: ?> text-green-600 <?php endif; ?>">
                                                <?php echo e($litter->current_age); ?> days
                                            </div>
                                            <div class="text-xs text-gray-500">
                                                <?php if($litter->days_overdue > 0): ?>
                                                    <?php echo e($litter->days_overdue); ?> days overdue
                                                <?php else: ?>
                                                    Ready now
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium text-gray-900"><?php echo e($litter->surviving_piglets); ?></div>
                                            <div class="text-xs text-gray-500">
                                                Born: <?php echo e($litter->live_births ?? 0); ?>

                                                <?php if($litter->pigletDeaths->sum('count') > 0): ?>
                                                    • Deaths: <?php echo e($litter->pigletDeaths->sum('count')); ?>

                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <?php echo e($litter->farrowing_date->format('M d, Y')); ?>

                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <?php if($litter->is_critical): ?>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                    Critical Overdue
                                                </span>
                                            <?php elseif($litter->is_overdue): ?>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                                    Overdue
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                    Ready
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <div class="flex space-x-2">
                                                <button onclick="openLitterWeaningModal(<?php echo e($litter->id); ?>, '<?php echo e($litter->sow->ear_tag_number); ?>', <?php echo e($litter->surviving_piglets); ?>, <?php echo e($litter->current_age); ?>)" class="inline-flex items-center px-3 py-1 bg-green-600 text-white text-xs rounded-md hover:bg-green-700">
                                                    <svg class="h-3 w-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                                                    </svg>
                                                    Wean Litter
                                                </button>
                                                <a href="<?php echo e(route('pigs.show', $litter->sow->id)); ?>" class="inline-flex items-center px-3 py-1 bg-gray-600 text-white text-xs rounded-md hover:bg-gray-700">
                                                    View Sow
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="px-6 py-4 border-t border-gray-200">
                        <div class="flex items-center justify-between">
                            <div class="text-sm text-gray-700">
                                Showing <?php echo e($readyNowLitters->firstItem()); ?> to <?php echo e($readyNowLitters->lastItem()); ?> of <?php echo e($readyNowLitters->total()); ?> litters
                            </div>
                            <div class="flex items-center space-x-2">
                                <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $readyNowLitters]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($readyNowLitters)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="px-6 py-12 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">No litters ready for weaning</h3>
                        <p class="mt-1 text-sm text-gray-500">All litters are either too young or already weaned.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- DUE SOON TAB -->
            <div x-show="activeTab === 'soon'" x-transition>
                <div class="mb-4">
                    <h3 class="text-lg font-semibold text-gray-900">Litters Due Soon (38-44 days old)</h3>
                    <p class="text-sm text-gray-600">Plan ahead for these upcoming weanings in the next 7 days.</p>
                </div>
                
                <?php if($dueSoonLitters->count() > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mother (Sow)</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Litter Age</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Days Until Weaning</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Surviving Piglets</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Farrowing Date</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__currentLoopData = $dueSoonLitters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $litter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-gray-50 bg-yellow-50">
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="flex-shrink-0 h-10 w-10">
                                                    <div class="h-10 w-10 rounded-full bg-yellow-200 flex items-center justify-center">
                                                        <span class="text-sm font-medium text-yellow-800">
                                                            🐷
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="ml-4">
                                                    <div class="text-sm font-medium text-gray-900"><?php echo e($litter->sow->ear_tag_number); ?></div>
                                                    <div class="text-xs text-gray-500"><?php echo e($litter->sow->code ?? 'N/A'); ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-yellow-600 font-medium">
                                            <?php echo e($litter->current_age); ?> days
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-yellow-600 font-medium">
                                            <?php echo e($litter->days_until_weaning); ?> days
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium text-gray-900"><?php echo e($litter->surviving_piglets); ?></div>
                                            <div class="text-xs text-gray-500">
                                                Born: <?php echo e($litter->live_births ?? 0); ?>

                                                <?php if($litter->pigletDeaths->sum('count') > 0): ?>
                                                    • Deaths: <?php echo e($litter->pigletDeaths->sum('count')); ?>

                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <?php echo e($litter->farrowing_date->format('M d, Y')); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="px-6 py-4 border-t border-gray-200">
                        <div class="flex items-center justify-between">
                            <div class="text-sm text-gray-700">
                                Showing <?php echo e($dueSoonLitters->firstItem()); ?> to <?php echo e($dueSoonLitters->lastItem()); ?> of <?php echo e($dueSoonLitters->total()); ?> litters
                            </div>
                            <div class="flex items-center space-x-2">
                                <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $dueSoonLitters]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dueSoonLitters)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="px-6 py-12 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">No litters due soon</h3>
                        <p class="mt-1 text-sm text-gray-500">No litters will reach weaning age in the next 7 days.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- IN PROGRESS TAB -->
            <div x-show="activeTab === 'progress'" x-transition>
                <div class="mb-4">
                    <h3 class="text-lg font-semibold text-gray-900">Weaned Animals (Growing to Maturity)</h3>
                    <p class="text-sm text-gray-600">Individual animals that have been weaned but haven't reached maturity (<?php echo e($maturityAge); ?> days).</p>
                </div>
                
                <?php if($inProgress->count() > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Animal</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Age</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Weaned</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Progress</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Weight</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__currentLoopData = $inProgress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $currentAge = (int) $pig->date_of_birth->diffInDays(now());
                                        $latestWeight = $pig->weights->first();
                                        $canComplete = $currentAge >= $maturityAge;
                                    ?>
                                    <tr class="hover:bg-gray-50 bg-blue-50">
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="flex-shrink-0 h-10 w-10">
                                                    <div class="h-10 w-10 rounded-full bg-blue-200 flex items-center justify-center">
                                                        <span class="text-sm font-medium text-blue-800">
                                                            <?php echo e($pig->gender === 'M' ? '🐗' : '🐷'); ?>

                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="ml-4">
                                                    <div class="text-sm font-medium text-gray-900"><?php echo e($pig->ear_tag_number); ?></div>
                                                    <div class="text-xs text-gray-500"><?php echo e($pig->code); ?> • <?php echo e($pig->gender === 'M' ? 'Male' : 'Female'); ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-blue-600 font-medium">
                                            <?php echo e($currentAge); ?> days
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <?php if($pig->weaning): ?>
                                                <div class="font-medium"><?php echo e($pig->weaning->weaning_date->format('M d, Y')); ?></div>
                                                <div class="text-xs text-gray-500"><?php echo e($pig->days_since_weaning); ?> days ago</div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                                    <div class="bg-blue-600 h-2 rounded-full" style="width: <?php echo e($pig->maturity_progress); ?>%"></div>
                                                </div>
                                                <span class="text-xs text-gray-600"><?php echo e(number_format($pig->maturity_progress, 0)); ?>%</span>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <?php if($latestWeight): ?>
                                                <div class="font-medium"><?php echo e($latestWeight->weight); ?> kg</div>
                                                <div class="text-xs text-gray-500"><?php echo e($latestWeight->weigh_date->format('M d')); ?></div>
                                            <?php else: ?>
                                                <span class="text-gray-400">No weight</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <div class="flex space-x-2">
                                                <?php if($canComplete): ?>
                                                    <button onclick="completeMaturity(<?php echo e($pig->id); ?>, '<?php echo e($pig->code); ?>')" class="inline-flex items-center px-3 py-1 bg-green-600 text-white text-xs rounded-md hover:bg-green-700">
                                                        Complete
                                                    </button>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('pigs.show', $pig->id)); ?>" class="inline-flex items-center px-3 py-1 bg-gray-600 text-white text-xs rounded-md hover:bg-gray-700">
                                                    View
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="px-6 py-4 border-t border-gray-200">
                        <div class="flex items-center justify-between">
                            <div class="text-sm text-gray-700">
                                Showing <?php echo e($inProgress->firstItem()); ?> to <?php echo e($inProgress->lastItem()); ?> of <?php echo e($inProgress->total()); ?> results
                            </div>
                            <div class="flex items-center space-x-2">
                                <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $inProgress]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inProgress)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="px-6 py-12 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">No animals in progress</h3>
                        <p class="mt-1 text-sm text-gray-500">No animals are currently in the weaning-to-maturity phase.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- COMPLETED TAB -->
            <div x-show="activeTab === 'completed'" x-transition>
                <div class="mb-4">
                    <h3 class="text-lg font-semibold text-gray-900">Completed Weaning Journey</h3>
                    <p class="text-sm text-gray-600">Animals that have completed the full weaning-to-maturity process.</p>
                </div>
                
                <?php if($completed->count() > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Animal</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Completed</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Age at Maturity</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Destination</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Completed By</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php $__currentLoopData = $completed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weaning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-gray-50 bg-green-50">
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="flex-shrink-0 h-10 w-10">
                                                    <div class="h-10 w-10 rounded-full bg-green-200 flex items-center justify-center">
                                                        <span class="text-sm font-medium text-green-800">
                                                            <?php echo e($weaning->pig->gender === 'M' ? '🐗' : '🐷'); ?>

                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="ml-4">
                                                    <div class="text-sm font-medium text-gray-900"><?php echo e($weaning->pig->ear_tag_number); ?></div>
                                                    <div class="text-xs text-gray-500"><?php echo e($weaning->pig->code); ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <?php echo e($weaning->maturity_completion_date->format('M d, Y')); ?>

                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <?php echo e($weaning->age_at_maturity_days); ?> days
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                                <?php if($weaning->next_destination === 'breeding'): ?> bg-purple-100 text-purple-800 
                                                <?php else: ?> bg-blue-100 text-blue-800 <?php endif; ?>">
                                                <?php echo e(ucfirst($weaning->next_destination ?? 'market')); ?>

                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo e($weaning->completedBy->name ?? 'N/A'); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="px-6 py-4 border-t border-gray-200">
                        <div class="flex items-center justify-between">
                            <div class="text-sm text-gray-700">
                                Showing <?php echo e($completed->firstItem()); ?> to <?php echo e($completed->lastItem()); ?> of <?php echo e($completed->total()); ?> results
                            </div>
                            <div class="flex items-center space-x-2">
                                <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $completed]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($completed)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="px-6 py-12 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">No completed records</h3>
                        <p class="mt-1 text-sm text-gray-500">No animals have completed the weaning journey yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Include the litter weaning modal -->
<?php echo $__env->make('weaning.partials.litter-weaning-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
function openLitterWeaningModal(litterId, sowTag, pigletCount, litterAge) {
    document.getElementById('litterModalTitle').textContent = `Wean Litter - Sow ${sowTag}`;
    document.getElementById('litterWeaningForm').action = `/weaning/litter/${litterId}/wean`;
    document.getElementById('litterWeaningModal').classList.remove('hidden');

    const form = document.getElementById('litterWeaningForm');
    let litterInfo = form.querySelector('.litter-info');
    if (!litterInfo) {
        litterInfo = document.createElement('div');
        litterInfo.className = 'litter-info mb-4 p-3 bg-green-50 rounded-md border border-green-200';
        form.insertBefore(litterInfo, form.firstChild);
    }
    litterInfo.innerHTML = `
        <div class="text-sm text-green-800">
            <strong>✅ READY FOR WEANING</strong><br>
            <strong>Mother:</strong> ${sowTag}<br>
            <strong>Litter Age:</strong> ${litterAge} days<br>
            <strong>Surviving Piglets:</strong> ${pigletCount}<br>
            <strong>Status:</strong> Ready for weaning
        </div>
    `;
}

function closeLitterWeaningModal() {
    document.getElementById('litterWeaningModal').classList.add('hidden');
    document.getElementById('litterWeaningForm').reset();
    const litterInfo = document.querySelector('.litter-info');
    if (litterInfo) {
        litterInfo.remove();
    }
}

function completeMaturity(pigId, pigCode) {
    if (confirm(`Complete maturity for ${pigCode}? This will move the animal to the completed section.`)) {
        fetch(`/weaning/${pigId}/complete-maturity`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Content-Type': 'application/json',
            },
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error completing maturity: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while completing maturity.');
        });
    }
}

// Close modal when clicking outside
document.getElementById('litterWeaningModal')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeLitterWeaningModal();
    }
});
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/charlotte/chipper-farms/resources/views/weaning/dashboard.blade.php ENDPATH**/ ?>