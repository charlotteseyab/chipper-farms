<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        :root{
            --bg: #f3f7fc;
            --panel: #ffffff;
            --panel-2: #f8fbff;
            --text: #0f172a;
            --muted: #64748b;
            --line: #e2e8f0;
            --line-soft: #edf2f7;
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --primary-soft: #eaf2ff;
            --success: #15803d;
            --success-dark: #166534;
            --success-soft: #ecfdf3;
            --warning: #b45309;
            --warning-soft: #fffbeb;
            --danger: #b91c1c;
            --danger-soft: #fef2f2;
            --indigo: #4338ca;
            --indigo-soft: #eef2ff;
            --emerald: #047857;
            --emerald-soft: #ecfdf5;
            --shadow: 0 18px 48px rgba(15, 23, 42, 0.07);
            --shadow-soft: 0 10px 25px rgba(15, 23, 42, 0.05);
            --radius-xl: 26px;
            --radius-lg: 20px;
            --radius-md: 14px;
        }

        .feed-page{
            min-height: 100vh;
            padding: 28px 0 48px;
            color: var(--text);
        }

        .feed-shell{
            max-width: 1380px;
            margin: 0 auto;
            padding: 0 16px;
        }

        .feed-stack{
            display: flex;
            flex-direction: column;
            gap: 24px;
        }

        .feed-hero{
            background: linear-gradient(135deg, #ffffff 0%, #f8fbff 100%);
            border: 1px solid var(--line-soft);
            border-radius: 30px;
            box-shadow: var(--shadow);
            padding: 28px;
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
        }

        .feed-hero-title{
            margin: 0;
            font-size: 2rem;
            line-height: 1.05;
            font-weight: 900;
            letter-spacing: -.04em;
            color: #0f172a;
        }

        .feed-hero-text{
            margin: 10px 0 0;
            max-width: 760px;
            font-size: .98rem;
            line-height: 1.7;
            color: var(--muted);
        }

        .feed-filter-card{
            background: #fff;
            border: 1px solid var(--line-soft);
            border-radius: 22px;
            box-shadow: var(--shadow-soft);
            padding: 10px;
            min-width: 320px;
        }

        .feed-filter-form{
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .feed-date-range{
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border: 1px solid var(--line);
            border-radius: 16px;
            background: #f8fafc;
        }

        .feed-date-range input[type="date"]{
            border: 0;
            background: transparent;
            font-size: .92rem;
            font-weight: 700;
            color: #334155;
            outline: none;
            box-shadow: none;
        }

        .feed-date-sep{
            color: #cbd5e1;
            font-weight: 700;
        }

        .feed-btn{
            appearance: none;
            border: 0;
            border-radius: 14px;
            padding: 12px 16px;
            font-size: .92rem;
            font-weight: 800;
            cursor: pointer;
            transition: .18s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .feed-btn-primary{
            color: #fff;
            background: linear-gradient(135deg, #2563eb 0%, #4338ca 100%);
            box-shadow: 0 12px 24px rgba(67, 56, 202, .22);
        }

        .feed-btn-primary:hover{
            transform: translateY(-1px);
            box-shadow: 0 18px 34px rgba(67, 56, 202, .26);
        }

        .feed-btn-secondary{
            color: #334155;
            background: #fff;
            border: 1px solid var(--line);
        }

        .feed-btn-secondary:hover{
            background: #f8fafc;
            border-color: #dbe3ee;
            color: #0f172a;
        }

        .feed-metrics{
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
        }

        .feed-metrics-wide{
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            align-items: stretch;
        }

        .metric-card{
            background: var(--panel);
            border: 1px solid var(--line-soft);
            border-radius: 24px;
            box-shadow: var(--shadow-soft);
            padding: 20px;
            position: relative;
            overflow: hidden;
            min-height: 170px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .metric-card::before{
            content: "";
            position: absolute;
            top: -24px;
            right: -24px;
            width: 96px;
            height: 96px;
            border-radius: 999px;
            background: rgba(37,99,235,.05);
        }

        .metric-card.metric-success::before{
            background: rgba(5,150,105,.08);
        }

        .metric-card.metric-warning::before{
            background: rgba(245,158,11,.10);
        }

        .metric-card.metric-danger::before{
            background: rgba(239,68,68,.08);
        }

        .metric-label{
            position: relative;
            z-index: 1;
            font-size: .76rem;
            text-transform: uppercase;
            letter-spacing: .08em;
            font-weight: 900;
            color: #64748b;
            margin-bottom: 10px;
        }

        .metric-value{
            position: relative;
            z-index: 1;
            font-size: 1.95rem;
            line-height: 1;
            font-weight: 900;
            color: #0f172a;
            margin: 4px 0 6px;
        }

        .metric-sub{
            position: relative;
            z-index: 1;
            margin-top: 8px;
            font-size: .84rem;
            color: var(--muted);
            line-height: 1.55;
        }

        .metric-card.metric-success .metric-value{
            color: var(--success-dark);
        }

        .metric-card.metric-warning .metric-value{
            color: var(--warning);
        }

        .metric-card.metric-danger .metric-value{
            color: var(--danger);
        }

        .metric-card.metric-clickable{
            appearance: none;
            width: 100%;
            text-align: left;
            cursor: pointer;
            transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
            font: inherit;
            background: var(--panel);
        }

        .metric-card.metric-clickable:hover{
            transform: translateY(-3px);
            box-shadow: 0 22px 48px rgba(15, 23, 42, 0.10);
            border-color: #dbeafe;
        }

        .metric-card.metric-clickable:focus{
            outline: none;
            box-shadow:
                0 0 0 4px rgba(37, 99, 235, 0.12),
                0 22px 48px rgba(15, 23, 42, 0.10);
        }

        .metric-detail-link{
            position: relative;
            z-index: 1;
            margin-top: 12px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: .78rem;
            font-weight: 800;
            color: var(--primary);
        }

        .metric-detail-link svg{
            width: 14px;
            height: 14px;
        }

        .panel{
            background: var(--panel);
            border: 1px solid var(--line-soft);
            border-radius: var(--radius-xl);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .panel-head{
            padding: 22px 24px 16px;
            border-bottom: 1px solid var(--line-soft);
            background: linear-gradient(180deg, #ffffff 0%, #fbfdff 100%);
        }

        .panel-title{
            margin: 0;
            font-size: 1.14rem;
            font-weight: 900;
            color: #0f172a;
            letter-spacing: -.01em;
        }

        .panel-text{
            margin: 8px 0 0;
            font-size: .9rem;
            color: var(--muted);
            line-height: 1.6;
        }

        .panel-body{
            padding: 20px 24px 24px;
        }

        .panel-grid-2{
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 24px;
        }

        .mini-note{
            border: 1px solid #fcd34d;
            background: #fff9db;
            color: #92400e;
            border-radius: 16px;
            padding: 14px 16px;
            font-size: .88rem;
            line-height: 1.55;
            margin-bottom: 18px;
        }

        .setup-list{
            display: grid;
            grid-template-columns: repeat(7, minmax(0, 1fr));
            gap: 12px;
            margin-bottom: 18px;
        }

        .setup-pill{
            border: 1px solid #d1fae5;
            background: #f0fdf4;
            border-radius: 16px;
            padding: 12px;
        }

        .setup-pill-label{
            display: block;
            font-size: .74rem;
            text-transform: uppercase;
            letter-spacing: .05em;
            color: #166534;
            font-weight: 800;
            margin-bottom: 6px;
        }

        .setup-pill-value{
            display: block;
            font-size: 1.05rem;
            font-weight: 900;
            color: #14532d;
        }

        .setup-pill-sub{
            display: block;
            margin-top: 4px;
            font-size: .76rem;
            color: #6b7280;
        }

        .table-card{
            border: 1px solid var(--line-soft);
            border-radius: 20px;
            overflow: hidden;
            background: #fff;
        }

        .table-head{
            padding: 14px 16px;
            background: #f8fafc;
            border-bottom: 1px solid var(--line-soft);
        }

        .table-head h4{
            margin: 0;
            font-size: .82rem;
            text-transform: uppercase;
            letter-spacing: .07em;
            font-weight: 900;
            color: #0f172a;
        }

        .table-wrap{
            overflow: auto;
            max-height: 430px;
        }

        .table-wrap::-webkit-scrollbar{
            width: 8px;
            height: 8px;
        }

        .table-wrap::-webkit-scrollbar-thumb{
            background: #cbd5e1;
            border-radius: 999px;
        }

        .data-table{
            width: 100%;
            min-width: 760px;
            border-collapse: collapse;
            font-size: .84rem;
        }

        .data-table thead th{
            position: sticky;
            top: 0;
            z-index: 2;
            background: #f8fafc;
            color: #475569;
            font-size: .72rem;
            text-transform: uppercase;
            letter-spacing: .07em;
            font-weight: 900;
            padding: 12px 12px;
            border-bottom: 1px solid var(--line-soft);
            text-align: left;
            white-space: nowrap;
        }

        .data-table tbody td{
            padding: 11px 12px;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
            vertical-align: middle;
        }

        .data-table tbody tr:hover{
            background: #fafcff;
        }

        /* .data-table td.num,
        .data-table th.num{
            text-align: right;
        } */

        .data-table td.center,
        .data-table th.center{
            text-align: center;
        }

        .row-total{
            background: #f8fafc;
            font-weight: 800;
        }

        .row-total td{
            color: #0f172a !important;
        }

        .pagination-row{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 14px 16px;
            border-top: 1px solid var(--line-soft);
            font-size: .8rem;
            color: var(--muted);
            flex-wrap: wrap;
        }

        .split-grid{
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 24px;
        }

        .tab-card{
            background: #fff;
            border: 1px solid var(--line-soft);
            border-radius: 24px;
            box-shadow: var(--shadow);
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .tab-head{
            padding: 18px 22px;
            border-bottom: 1px solid var(--line-soft);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            flex-wrap: wrap;
        }

        .tab-title{
            margin: 0;
            font-size: 1.02rem;
            font-weight: 900;
            color: #0f172a;
        }

        .tab-switch{
            display: inline-flex;
            gap: 6px;
            background: #f1f5f9;
            padding: 4px;
            border-radius: 14px;
        }

        .tab-switch button{
            border: 0;
            background: transparent;
            color: #64748b;
            font-size: .78rem;
            font-weight: 800;
            padding: 8px 12px;
            border-radius: 10px;
            cursor: pointer;
            transition: .18s ease;
        }

        .tab-switch button.is-active,
        .tab-switch button:hover{
            background: #fff;
            color: #0f172a;
            box-shadow: 0 2px 8px rgba(15, 23, 42, .06);
        }

        .chart-panel{
            background: #fff;
            border: 1px solid var(--line-soft);
            border-radius: 24px;
            box-shadow: var(--shadow);
            padding: 22px 24px 24px;
        }

        .chart-title{
            margin: 0;
            font-size: 1.08rem;
            font-weight: 900;
            color: #0f172a;
        }

        .chart-text{
            margin: 6px 0 18px;
            font-size: .9rem;
            color: var(--muted);
        }

        .chart-box{
            height: 340px;
            width: 100%;
        }

        .muted-empty{
            padding: 22px;
            text-align: center;
            color: #94a3b8;
            font-size: .88rem;
        }

        .report-modal{
            position: fixed;
            inset: 0;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(15, 23, 42, 0.56);
            z-index: 9999;
        }

        .report-modal.is-open{
            display: flex;
        }

        .report-modal-card{
            width: min(760px, 100%);
            max-height: 88vh;
            overflow: hidden;
            background: #ffffff;
            border-radius: 28px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 30px 70px rgba(15, 23, 42, 0.22);
        }

        .report-modal-head{
            padding: 20px 22px 16px;
            border-bottom: 1px solid var(--line-soft);
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
            background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
        }

        .report-modal-title{
            margin: 0;
            font-size: 1.1rem;
            font-weight: 900;
            color: #0f172a;
        }

        .report-modal-sub{
            margin: 6px 0 0;
            font-size: .86rem;
            color: var(--muted);
            line-height: 1.6;
        }

        .report-modal-close{
            width: 40px;
            height: 40px;
            border-radius: 999px;
            border: 0;
            background: #f1f5f9;
            color: #334155;
            font-size: 1rem;
            font-weight: 900;
            cursor: pointer;
            transition: .18s ease;
        }

        .report-modal-close:hover{
            background: #e2e8f0;
        }

        .report-modal-body{
            padding: 20px 22px 24px;
            overflow: auto;
            max-height: calc(88vh - 86px);
        }

        .modal-highlight{
            border: 1px solid #dbeafe;
            background: #eff6ff;
            border-radius: 18px;
            padding: 16px;
            margin-bottom: 18px;
        }

        .modal-highlight-label{
            font-size: .75rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: .08em;
            color: #1d4ed8;
            margin-bottom: 6px;
        }

        .modal-highlight-value{
            font-size: 2rem;
            font-weight: 900;
            color: #0f172a;
            line-height: 1;
        }

        .modal-highlight-sub{
            margin-top: 8px;
            font-size: .86rem;
            color: #475569;
            line-height: 1.55;
        }

        .modal-grid{
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
            margin-bottom: 18px;
        }

        .modal-stat{
            border: 1px solid var(--line-soft);
            background: #fff;
            border-radius: 16px;
            padding: 14px;
        }

        .modal-stat-label{
            display: block;
            font-size: .74rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: .06em;
            color: #64748b;
            margin-bottom: 6px;
        }

        .modal-stat-value{
            display: block;
            font-size: 1.08rem;
            font-weight: 900;
            color: #0f172a;
        }

        .modal-copy{
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        .modal-copy-block{
            border: 1px solid var(--line-soft);
            background: #fcfdff;
            border-radius: 16px;
            padding: 14px 16px;
        }

        .modal-copy-title{
            margin: 0 0 6px;
            font-size: .88rem;
            font-weight: 900;
            color: #0f172a;
        }

        .modal-copy-text{
            margin: 0;
            font-size: .88rem;
            color: #475569;
            line-height: 1.7;
        }

        @media (max-width: 1200px){
            .feed-metrics{
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .feed-metrics-wide,
            .setup-list{
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .panel-grid-2,
            .split-grid{
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px){
            .feed-hero{
                padding: 22px 18px;
            }

            .feed-hero-title{
                font-size: 1.7rem;
            }

            .feed-filter-card{
                width: 100%;
                min-width: 0;
            }

            .feed-filter-form{
                align-items: stretch;
            }

            .feed-date-range{
                width: 100%;
                justify-content: space-between;
            }

            .feed-btn{
                width: 100%;
            }

            .feed-metrics,
            .feed-metrics-wide{
                grid-template-columns: 1fr;
            }

            .setup-list{
                grid-template-columns: 1fr 1fr;
            }

            .panel-head,
            .panel-body,
            .tab-head,
            .chart-panel{
                padding-left: 16px;
                padding-right: 16px;
            }

            .modal-grid{
                grid-template-columns: 1fr;
            }
        }
    </style>

    <?php
        $firstWeeklyTotal = collect($weeklyIdealTotals ?? [])->first()['total'] ?? 0;
        $firstMonthlyTotal = collect($monthlyIdealTotals ?? [])->first()['total'] ?? 0;
        $ingredientCount = count($ingredientDetails ?? []);

        $weekNeedClass = ($weeklyPurchaseNeedKg ?? 0) > 0 ? 'metric-warning' : 'metric-success';
        $monthNeedClass = ($monthlyPurchaseNeedKg ?? 0) > 0 ? 'metric-danger' : 'metric-success';

        $currentAnimalsModal = [
            'highlight_label' => 'Current total animals',
            'highlight_value' => number_format($currentTotalAnimals ?? 0),
            'highlight_sub' => 'This value is based on the same stock logic used on the main dashboard.',
            'stats' => [
                ['label' => 'Total pigs', 'value' => number_format($currentTotalAnimals ?? 0)],
                ['label' => 'Piglets', 'value' => number_format($currentPigletsCount ?? 0)],
                ['label' => 'Active weaned pigs', 'value' => number_format($currentWeanedPigCount ?? 0)],
                ['label' => 'Snapshot date', 'value' => $currentSnapshotDate ?? $to],
            ],
            'blocks' => [
                [
                    'title' => 'How this is calculated',
                    'text' => 'The total animal figure is taken from the same stock logic used on the main dashboard. Piglets come from active farrowings within the configured weaning age, while active weaned pigs come from Pig Management records that are still active.',
                ],
                [
                    'title' => 'Why this may differ from feed-stage counts',
                    'text' => 'This total is a stock snapshot, while feed-stage counts such as weaners, growers, finishers, and pregnant sows are forecasting buckets. Those buckets are used to estimate feed demand and may not always reconcile exactly with the full stock total.',
                ],
                [
                    'title' => 'What this number tells you',
                    'text' => 'This is the best top-level current population figure for management and reporting. It helps explain the scale of the farm at the selected reporting date.',
                ],
            ],
        ];

        $feedOnHandModal = [
            'highlight_label' => 'Available feed stock',
            'highlight_value' => number_format($totalFeedOnHandKg ?? 0, 1) . ' kg',
            'highlight_sub' => 'This is the normalized on-hand stock used for purchase gap checks.',
            'stats' => [
                ['label' => 'Total kg on hand', 'value' => number_format($totalFeedOnHandKg ?? 0, 1) . ' kg'],
                ['label' => 'Bag conversion', 'value' => number_format($kgPerBag ?? 0, 1) . ' kg / bag'],
                ['label' => 'Used in purchase check', 'value' => 'Yes'],
                ['label' => 'Stock basis', 'value' => 'Manufactured feed inventory'],
            ],
            'blocks' => [
                [
                    'title' => 'How this is calculated',
                    'text' => 'All feed inventory records are normalized into kilograms. Entries already stored in kilograms stay as they are. Entries stored in bags are converted to kilograms using the configured kg-per-bag setting.',
                ],
                [
                    'title' => 'Why this matters',
                    'text' => 'This stock number is compared directly against projected feed demand for the selected week and month. It helps determine whether the farm can meet feed requirements without additional purchases.',
                ],
                [
                    'title' => 'Interpretation',
                    'text' => 'A higher on-hand figure reduces purchase pressure. A lower on-hand figure means the weekly and monthly purchase cards are more likely to show a shortfall.',
                ],
            ],
        ];

        $weeklyNeedModal = [
            'highlight_label' => 'Weekly requirement',
            'highlight_value' => number_format($selectedWeeklyNeedKg ?? 0, 1) . ' kg',
            'highlight_sub' => 'Forecast demand for ' . ($currentWeekKey ?? 'current week'),
            'stats' => [
                ['label' => 'Week', 'value' => $currentWeekKey ?? 'N/A'],
                ['label' => 'Piglets', 'value' => number_format($weeklyIdealTotals[$currentWeekKey]['piglets'] ?? 0, 1) . ' kg'],
                ['label' => 'Weaners', 'value' => number_format($weeklyIdealTotals[$currentWeekKey]['weaners'] ?? 0, 1) . ' kg'],
                ['label' => 'Growers', 'value' => number_format($weeklyIdealTotals[$currentWeekKey]['growers'] ?? 0, 1) . ' kg'],
                ['label' => 'Finishers', 'value' => number_format($weeklyIdealTotals[$currentWeekKey]['finishers'] ?? 0, 1) . ' kg'],
                ['label' => 'Pregnant sows', 'value' => number_format($weeklyIdealTotals[$currentWeekKey]['pregnant_sows'] ?? 0, 1) . ' kg'],
            ],
            'blocks' => [
                [
                    'title' => 'How this is calculated',
                    'text' => 'The weekly requirement is calculated by taking current feed-stage animal counts and multiplying each stage by its configured kg per animal per day, then summing the daily totals across the week.',
                ],
                [
                    'title' => 'Why it may rise or fall',
                    'text' => 'This number changes when animal counts shift between stages, when new litters are added, when pigs mature into heavier feed categories, or when stage feed settings are changed.',
                ],
                [
                    'title' => 'How to use it',
                    'text' => 'This is your ideal weekly target for planning stock and purchase decisions. It should be compared against feed on hand and, where relevant, against actual fed totals.',
                ],
            ],
        ];

        $monthlyNeedModal = [
            'highlight_label' => 'Monthly requirement',
            'highlight_value' => number_format($selectedMonthlyNeedKg ?? 0, 1) . ' kg',
            'highlight_sub' => 'Forecast demand for ' . ($currentMonthKey ?? 'current month'),
            'stats' => [
                ['label' => 'Month', 'value' => $currentMonthKey ?? 'N/A'],
                ['label' => 'Piglets', 'value' => number_format($monthlyIdealTotals[$currentMonthKey]['piglets'] ?? 0, 1) . ' kg'],
                ['label' => 'Weaners', 'value' => number_format($monthlyIdealTotals[$currentMonthKey]['weaners'] ?? 0, 1) . ' kg'],
                ['label' => 'Growers', 'value' => number_format($monthlyIdealTotals[$currentMonthKey]['growers'] ?? 0, 1) . ' kg'],
                ['label' => 'Finishers', 'value' => number_format($monthlyIdealTotals[$currentMonthKey]['finishers'] ?? 0, 1) . ' kg'],
                ['label' => 'Pregnant sows', 'value' => number_format($monthlyIdealTotals[$currentMonthKey]['pregnant_sows'] ?? 0, 1) . ' kg'],
            ],
            'blocks' => [
                [
                    'title' => 'How this is calculated',
                    'text' => 'The monthly requirement is the sum of projected daily stage needs across the selected month, based on animal counts and configured feed settings.',
                ],
                [
                    'title' => 'Why this is useful',
                    'text' => 'This gives a broader planning view than the weekly card. It helps with purchasing cycles, budgeting, and checking whether stock and ingredient plans are sufficient over a longer horizon.',
                ],
                [
                    'title' => 'Interpretation',
                    'text' => 'If this number is significantly larger than stock on hand, the purchase-this-month card will show a shortfall that should be addressed before the month progresses.',
                ],
            ],
        ];

        $weeklyPurchaseModal = [
            'highlight_label' => 'Weekly purchase need',
            'highlight_value' => number_format($weeklyPurchaseNeedKg ?? 0, 1) . ' kg',
            'highlight_sub' => (($weeklyPurchaseNeedKg ?? 0) > 0)
                ? 'Shortfall detected for the selected week.'
                : 'Current stock is enough for the selected week.',
            'stats' => [
                ['label' => 'Week needed', 'value' => number_format($selectedWeeklyNeedKg ?? 0, 1) . ' kg'],
                ['label' => 'Feed on hand', 'value' => number_format($totalFeedOnHandKg ?? 0, 1) . ' kg'],
                ['label' => 'Purchase shortfall', 'value' => number_format($weeklyPurchaseNeedKg ?? 0, 1) . ' kg'],
                ['label' => 'Approx. bags', 'value' => number_format(ceil($weeklyPurchaseNeedBags ?? 0)) . ' bags'],
            ],
            'blocks' => [
                [
                    'title' => 'How this is calculated',
                    'text' => 'This card compares the weekly projected feed requirement against the total manufactured feed currently on hand. The result is purchase need = max(0, weekly required - feed on hand).',
                ],
                [
                    'title' => 'Why the value may be zero',
                    'text' => 'If stock on hand is greater than or equal to projected weekly requirement, the shortfall becomes zero. That means no additional feed purchase is required for the selected week.',
                ],
                [
                    'title' => 'Why the value may be high',
                    'text' => 'A high weekly shortfall usually means demand is increasing faster than available stock, stock has not been replenished recently, or the projected animal-stage demand is particularly heavy.',
                ],
            ],
        ];

        $monthlyPurchaseModal = [
            'highlight_label' => 'Monthly purchase need',
            'highlight_value' => number_format($monthlyPurchaseNeedKg ?? 0, 1) . ' kg',
            'highlight_sub' => (($monthlyPurchaseNeedKg ?? 0) > 0)
                ? 'Shortfall detected for the selected month.'
                : 'Current stock is enough for the selected month.',
            'stats' => [
                ['label' => 'Month needed', 'value' => number_format($selectedMonthlyNeedKg ?? 0, 1) . ' kg'],
                ['label' => 'Feed on hand', 'value' => number_format($totalFeedOnHandKg ?? 0, 1) . ' kg'],
                ['label' => 'Purchase shortfall', 'value' => number_format($monthlyPurchaseNeedKg ?? 0, 1) . ' kg'],
                ['label' => 'Approx. bags', 'value' => number_format(ceil($monthlyPurchaseNeedBags ?? 0)) . ' bags'],
            ],
            'blocks' => [
                [
                    'title' => 'How this is calculated',
                    'text' => 'This card compares the monthly projected requirement against current feed on hand. The monthly shortfall is max(0, monthly required - feed on hand).',
                ],
                [
                    'title' => 'What makes this more strategic',
                    'text' => 'Unlike the weekly card, the monthly purchase view helps with larger planning decisions such as procurement timing, supplier coordination, and budget preparation.',
                ],
                [
                    'title' => 'Why this card matters most',
                    'text' => 'This is usually the strongest early warning card on the page. A high monthly gap means the farm may not sustain feed operations without timely replenishment.',
                ],
            ],
        ];
    ?>

    <?php
    $totalScheduledModal = [
        'highlight_label' => 'Total scheduled feed',
        'highlight_value' => number_format($totalScheduledKg ?? 0, 1) . ' kg',
        'highlight_sub' => 'This is the total amount of feed that has been scheduled within the selected reporting period.',
        'stats' => [
            ['label' => 'Scheduled total', 'value' => number_format($totalScheduledKg ?? 0, 1) . ' kg'],
            ['label' => 'Reporting start', 'value' => $from ?? '-'],
            ['label' => 'Reporting end', 'value' => $to ?? '-'],
            ['label' => 'Based on', 'value' => 'Feed schedule records'],
        ],
        'blocks' => [
            [
                'title' => 'What this means',
                'text' => 'This card shows the total scheduled feed quantity across all feed schedule entries found in the selected date range.',
            ],
            [
                'title' => 'How it is calculated',
                'text' => 'The value is calculated by summing the planned amount from all feed schedules between the selected start and end dates.',
            ],
            [
                'title' => 'Why it matters',
                'text' => 'This number helps you see the total operational feed volume planned for the reporting period and compare it against ideal projections, actual feeding, and available stock.',
            ],
        ],
    ];


$weeklyNeedModal = [
    'highlight_label' => 'Weekly requirement',
    'highlight_value' => number_format($selectedWeeklyNeedKg ?? 0, 1) . ' kg',
    'highlight_sub' => 'Projected demand for ' . ($currentWeekKey ?? 'current week'),
    'stats' => [
        ['label' => 'Week', 'value' => $currentWeekKey ?? 'N/A'],
        ['label' => 'Projected total', 'value' => number_format($selectedWeeklyNeedKg ?? 0, 1) . ' kg'],
        ['label' => 'Shortfall total', 'value' => number_format($weeklyPurchaseNeedKg ?? 0, 1) . ' kg'],
        ['label' => 'Estimated bags needed', 'value' => number_format(ceil($weeklyPurchaseNeedBags ?? 0))],
    ],
    'table' => [
        'columns' => [
            ['key' => 'feed_type', 'label' => 'Feed Type'],
            ['key' => 'on_hand_bags', 'label' => 'Bags Available', 'numeric' => true],
            ['key' => 'needed_kg', 'label' => 'Needed (kg)', 'numeric' => true],
            ['key' => 'shortfall_kg', 'label' => 'Shortfall (kg)', 'numeric' => true],
            ['key' => 'bags_needed', 'label' => 'Bags Needed', 'numeric' => true],
        ],
        'rows' => collect($selectedWeeklyBreakdown ?? [])->map(fn ($row) => [
            'feed_type' => $row['feed_type'],
            'on_hand_bags' => number_format((float) $row['on_hand_bags'], 1),
            'needed_kg' => number_format((float) $row['needed_kg'], 1),
            'shortfall_kg' => number_format((float) $row['shortfall_kg'], 1),
            'bags_needed' => number_format((float) $row['bags_needed'], 0),
        ])->all(),
    ],
    'blocks' => [
        [
            'title' => 'What this shows',
            'text' => 'This table breaks the weekly feed projection down by exact feed type, showing how many bags are currently available and where shortages exist.',
        ],
        [
            'title' => 'How to read it',
            'text' => 'If shortfall is zero for a feed type, stock is enough. If shortfall is above zero, that feed type needs replenishment, and the bags needed column shows the estimated purchase quantity.',
        ],
    ],
];


$monthlyNeedModal = [
    'highlight_label' => 'Monthly requirement',
    'highlight_value' => number_format($selectedMonthlyNeedKg ?? 0, 1) . ' kg',
    'highlight_sub' => 'Projected demand for ' . ($currentMonthKey ?? 'current month'),
    'stats' => [
        ['label' => 'Month', 'value' => $currentMonthKey ?? 'N/A'],
        ['label' => 'Projected total', 'value' => number_format($selectedMonthlyNeedKg ?? 0, 1) . ' kg'],
        ['label' => 'Shortfall total', 'value' => number_format($monthlyPurchaseNeedKg ?? 0, 1) . ' kg'],
        ['label' => 'Estimated bags needed', 'value' => number_format(ceil($monthlyPurchaseNeedBags ?? 0))],
    ],
    'table' => [
        'columns' => [
            ['key' => 'feed_type', 'label' => 'Feed Type'],
            ['key' => 'on_hand_bags', 'label' => 'Bags Available', 'numeric' => true],
            ['key' => 'needed_kg', 'label' => 'Needed (kg)', 'numeric' => true],
            ['key' => 'shortfall_kg', 'label' => 'Shortfall (kg)', 'numeric' => true],
            ['key' => 'bags_needed', 'label' => 'Bags Needed', 'numeric' => true],
        ],
        'rows' => collect($selectedMonthlyBreakdown ?? [])->map(fn ($row) => [
            'feed_type' => $row['feed_type'],
            'on_hand_bags' => number_format((float) $row['on_hand_bags'], 1),
            'needed_kg' => number_format((float) $row['needed_kg'], 1),
            'shortfall_kg' => number_format((float) $row['shortfall_kg'], 1),
            'bags_needed' => number_format((float) $row['bags_needed'], 0),
        ])->all(),
    ],
    'blocks' => [
        [
            'title' => 'What this shows',
            'text' => 'This monthly breakdown shows exactly which feed types will be adequate and which ones will fall short over the selected month.',
        ],
        [
            'title' => 'Why this matters',
            'text' => 'A monthly view is more useful for supplier planning and bulk purchasing because it shows larger demand pressure by feed type.',
        ],
    ],
];


    $ingredientsTrackedModal = [
        'highlight_label' => 'Tracked ingredients',
        'highlight_value' => number_format($ingredientCount ?? 0),
        'highlight_sub' => 'These are the ingredients currently appearing in your feed recipe analytics.',
        'stats' => [
            ['label' => 'Ingredient count', 'value' => number_format($ingredientCount ?? 0)],
            ['label' => 'Source', 'value' => 'Feed type recipes'],
            ['label' => 'Used for', 'value' => 'Actual + projected ingredient breakdown'],
            ['label' => 'Coverage', 'value' => 'Ingredients appearing in mapped recipes'],
        ],
        'blocks' => [
            [
                'title' => 'What this means',
                'text' => 'This card shows how many distinct ingredients appear in the recipe and ingredient analysis currently loaded into the report.',
            ],
            [
                'title' => 'How it is calculated',
                'text' => 'The count is derived from the ingredient detail collection built from feed type recipes and related ingredient usage/projection data.',
            ],
            [
                'title' => 'Why it matters',
                'text' => 'A higher ingredient count usually means more recipe complexity and more purchasing lines to manage. It also affects how detailed your ingredient projection tables can be.',
            ],
        ],
    ];
?>

<?php
    $weeklyIdealFeedModal = [
        'highlight_label' => 'Weekly ideal feed',
        'highlight_value' => number_format($firstWeeklyTotal ?? 0, 1) . ' kg',
        'highlight_sub' => 'This is the total ideal projected feed for the first visible projected week in the current report.',
        'stats' => [
            ['label' => 'Projected week total', 'value' => number_format($firstWeeklyTotal ?? 0, 1) . ' kg'],
            ['label' => 'Week reference', 'value' => collect($weeklyIdealTotals ?? [])->keys()->first() ?? 'N/A'],
            ['label' => 'Projection basis', 'value' => 'Animal stage counts × daily feed setup'],
            ['label' => 'Type', 'value' => 'Ideal requirement'],
        ],
        'blocks' => [
            [
                'title' => 'What this means',
                'text' => 'This card summarizes the ideal amount of feed needed for the first projected week currently visible in the report.',
            ],
            [
                'title' => 'How it is calculated',
                'text' => 'The weekly total is built from daily feed requirements for piglets, weaners, growers, finishers, and pregnant sows, then summed for that week.',
            ],
            [
                'title' => 'Why it may change',
                'text' => 'This number changes when animal counts change, when animals move between growth stages, or when stage feed setup values are adjusted.',
            ],
        ],
    ];

    $monthlyIdealFeedModal = [
        'highlight_label' => 'Monthly ideal feed',
        'highlight_value' => number_format($firstMonthlyTotal ?? 0, 1) . ' kg',
        'highlight_sub' => 'This is the total ideal projected feed for the first visible projected month in the current report.',
        'stats' => [
            ['label' => 'Projected month total', 'value' => number_format($firstMonthlyTotal ?? 0, 1) . ' kg'],
            ['label' => 'Month reference', 'value' => collect($monthlyIdealTotals ?? [])->keys()->first() ?? 'N/A'],
            ['label' => 'Projection basis', 'value' => 'Animal stage counts × daily feed setup'],
            ['label' => 'Type', 'value' => 'Ideal requirement'],
        ],
        'blocks' => [
            [
                'title' => 'What this means',
                'text' => 'This card shows the ideal projected feed required for the first visible month in the report.',
            ],
            [
                'title' => 'How it is calculated',
                'text' => 'The monthly total is the sum of all daily projected feed requirements across the month, based on feed-stage populations and your configured per-animal feed settings.',
            ],
            [
                'title' => 'Why it matters',
                'text' => 'This gives a broader planning number for procurement, budgeting, and monthly feed preparation.',
            ],
        ],
    ];

    $ingredientsTrackedModal = [
        'highlight_label' => 'Tracked ingredients',
        'highlight_value' => number_format($ingredientCount ?? 0),
        'highlight_sub' => 'These are the ingredients currently appearing in your feed recipe analytics.',
        'stats' => [
            ['label' => 'Ingredient count', 'value' => number_format($ingredientCount ?? 0)],
            ['label' => 'Source', 'value' => 'Feed type recipes'],
            ['label' => 'Used for', 'value' => 'Actual + projected ingredient breakdown'],
            ['label' => 'Coverage', 'value' => 'Ingredients appearing in mapped recipes'],
        ],
        'blocks' => [
            [
                'title' => 'What this means',
                'text' => 'This card shows how many distinct ingredients appear in the recipe and ingredient analysis currently loaded into the report.',
            ],
            [
                'title' => 'How it is calculated',
                'text' => 'The count is derived from the ingredient detail collection built from feed type recipes and related ingredient usage and projection data.',
            ],
            [
                'title' => 'Why it matters',
                'text' => 'A higher ingredient count usually means more recipe complexity and more purchasing lines to manage. It also affects how detailed your ingredient projection tables can be.',
            ],
        ],
    ];

    $totalScheduledModal = [
        'highlight_label' => 'Total scheduled feed',
        'highlight_value' => number_format($totalScheduledKg ?? 0, 1) . ' kg',
        'highlight_sub' => 'This is the total amount of feed that has been scheduled within the selected reporting period.',
        'stats' => [
            ['label' => 'Scheduled total', 'value' => number_format($totalScheduledKg ?? 0, 1) . ' kg'],
            ['label' => 'Reporting start', 'value' => $from ?? '-'],
            ['label' => 'Reporting end', 'value' => $to ?? '-'],
            ['label' => 'Based on', 'value' => 'Feed schedule records'],
        ],
        'blocks' => [
            [
                'title' => 'What this means',
                'text' => 'This card shows the total scheduled feed quantity across all feed schedule entries found in the selected date range.',
            ],
            [
                'title' => 'How it is calculated',
                'text' => 'The value is calculated by summing the planned amount from all feed schedules between the selected start and end dates.',
            ],
            [
                'title' => 'Why it matters',
                'text' => 'This number helps you see the total operational feed volume planned for the reporting period and compare it against ideal projections, actual feeding, and available stock.',
            ],
        ],
    ];
?> 

    <div class="feed-page">
        <div class="feed-shell">
            <div class="feed-stack">

                <section class="feed-hero">
                    <div>
                        <h1 class="feed-hero-title">Feed Analytics</h1>
                        <p class="feed-hero-text">
                            Project feed requirements from animal population, break them into ingredient materials, and monitor consumption by structure and room across the farm.
                        </p>
                    </div>

                    <div class="feed-filter-card">
                        <form method="GET" class="feed-filter-form">
                            <div class="feed-date-range">
                                <input type="date" name="start_date" value="<?php echo e($from ?? now()->subDays(30)->toDateString()); ?>">
                                <span class="feed-date-sep">|</span>
                                <input type="date" name="end_date" value="<?php echo e($to ?? now()->toDateString()); ?>">
                            </div>

                            <button type="submit" class="feed-btn feed-btn-primary">
                                Update View
                            </button>

                            <a href="<?php echo e(route('feeds.reports.export.pdf', ['start_date' => $from, 'end_date' => $to])); ?>" class="feed-btn feed-btn-secondary">
                                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                </svg>
                                Export PDF
                            </a>
                        </form>
                    </div>
                </section>

                <section class="feed-metrics">
                    <button
                        type="button"
                        class="metric-card metric-clickable"
                        data-modal-title="Total Scheduled"
                        data-modal-sub="Scheduled feed volume within the selected reporting period."
                        data-modal-content='<?php echo e(json_encode($totalScheduledModal)); ?>'>
                        <div class="metric-label">Total Scheduled</div>
                        <p class="metric-value"><?php echo e(number_format($totalScheduledKg ?? 0, 1)); ?></p>
                        <div class="metric-sub">kg scheduled in selected range</div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button>

                    <!-- <button
                        type="button"
                        class="metric-card metric-clickable metric-success"
                        data-modal-title="Weekly Ideal Feed"
                        data-modal-sub="Ideal projected feed requirement for the first visible projected week."
                        data-modal-content='<?php echo e(json_encode($weeklyIdealFeedModal)); ?>'>
                        <div class="metric-label">Weekly Ideal Feed</div>
                        <p class="metric-value"><?php echo e(number_format($firstWeeklyTotal, 1)); ?></p>
                        <div class="metric-sub">kg for first visible projected week</div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button> -->

                    <button
                        type="button"
                        class="metric-card metric-clickable metric-success"
                        data-modal-title="Monthly Ideal Feed"
                        data-modal-sub="Ideal projected feed requirement for the first visible projected month."
                        data-modal-content='<?php echo e(json_encode($monthlyIdealFeedModal)); ?>'>
                        <div class="metric-label">Monthly Ideal Feed</div>
                        <p class="metric-value"><?php echo e(number_format($firstMonthlyTotal, 1)); ?></p>
                        <div class="metric-sub">kg for first visible projected month</div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button>

                    <button
                        type="button"
                        class="metric-card metric-clickable"
                        data-modal-title="Ingredients Tracked"
                        data-modal-sub="Distinct ingredients represented in current recipe analytics."
                        data-modal-content='<?php echo e(json_encode($ingredientsTrackedModal)); ?>'>
                        <div class="metric-label">Ingredients Tracked</div>
                        <p class="metric-value"><?php echo e(number_format($ingredientCount)); ?></p>
                        <div class="metric-sub">ingredients appearing in recipes</div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button>
                </section>

                <section class="feed-metrics-wide">
                    <button
                        type="button"
                        class="metric-card metric-clickable"
                        data-modal-title="Current Animals"
                        data-modal-sub="Live farm population snapshot aligned with the main dashboard logic."
                        data-modal-content='<?php echo e(json_encode($currentAnimalsModal)); ?>'>
                        <div class="metric-label">Current Animals</div>
                        <p class="metric-value"><?php echo e(number_format($currentTotalAnimals ?? 0)); ?></p>
                        <div class="metric-sub">
                            <?php echo e(number_format($currentWeanedPigCount ?? 0)); ?> active pigs + <?php echo e(number_format($currentPigletsCount ?? 0)); ?> piglets
                        </div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button>

                    <button
                        type="button"
                        class="metric-card metric-clickable metric-success"
                        data-modal-title="Feed On Hand"
                        data-modal-sub="Manufactured feed stock currently available across inventory records."
                        data-modal-content='<?php echo e(json_encode($feedOnHandModal)); ?>'>
                        <div class="metric-label">Feed On Hand</div>
                        <p class="metric-value"><?php echo e(number_format($totalFeedOnHandKg ?? 0, 1)); ?></p>
                        <div class="metric-sub">kg currently available in manufactured feed stock</div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button>

                    <button
                        type="button"
                        class="metric-card metric-clickable"
                        data-modal-title="Need This Week"
                        data-modal-sub="Projected feed demand for the selected reporting week."
                        data-modal-content='<?php echo e(json_encode($weeklyNeedModal)); ?>'>
                        <div class="metric-label">Need This Week</div>
                        <p class="metric-value"><?php echo e(number_format($selectedWeeklyNeedKg ?? 0, 1)); ?></p>
                        <div class="metric-sub">kg required for <?php echo e($currentWeekKey ?? 'current week'); ?></div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button>

                    <button
                        type="button"
                        class="metric-card metric-clickable"
                        data-modal-title="Need This Month"
                        data-modal-sub="Projected feed demand for the selected reporting month."
                        data-modal-content='<?php echo e(json_encode($monthlyNeedModal)); ?>'>
                        <div class="metric-label">Need This Month</div>
                        <p class="metric-value"><?php echo e(number_format($selectedMonthlyNeedKg ?? 0, 1)); ?></p>
                        <div class="metric-sub">kg required for <?php echo e($currentMonthKey ?? 'current month'); ?></div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button>

                    <button
                        type="button"
                        class="metric-card metric-clickable <?php echo e($weekNeedClass); ?>"
                        data-modal-title="Purchase This Week"
                        data-modal-sub="Weekly stock gap based on projected feed demand versus current available stock."
                        data-modal-content='<?php echo e(json_encode($weeklyPurchaseModal)); ?>'>
                        <div class="metric-label">Purchase This Week</div>
                        <p class="metric-value"><?php echo e(number_format($weeklyPurchaseNeedKg ?? 0, 1)); ?></p>
                        <div class="metric-sub">
                            kg shortfall
                            <?php if(($weeklyPurchaseNeedKg ?? 0) > 0): ?>
                                • about <?php echo e(number_format(ceil($weeklyPurchaseNeedBags ?? 0))); ?> bags
                            <?php else: ?>
                                • current stock is enough
                            <?php endif; ?>
                        </div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button>

                    <button
                        type="button"
                        class="metric-card metric-clickable <?php echo e($monthNeedClass); ?>"
                        data-modal-title="Purchase This Month"
                        data-modal-sub="Monthly stock gap based on projected feed demand versus current available stock."
                        data-modal-content='<?php echo e(json_encode($monthlyPurchaseModal)); ?>'>
                        <div class="metric-label">Purchase This Month</div>
                        <p class="metric-value"><?php echo e(number_format($monthlyPurchaseNeedKg ?? 0, 1)); ?></p>
                        <div class="metric-sub">
                            kg shortfall
                            <?php if(($monthlyPurchaseNeedKg ?? 0) > 0): ?>
                                • about <?php echo e(number_format(ceil($monthlyPurchaseNeedBags ?? 0))); ?> bags
                            <?php else: ?>
                                • current stock is enough
                            <?php endif; ?>
                        </div>
                        <div class="metric-detail-link">
                            View details
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </div>
                    </button>
                </section>

                <section class="panel">
                    <div class="panel-head">
                        <h2 class="panel-title">Ideal Feed Requirement</h2>
                        <p class="panel-text">
                            Feed requirement is calculated from live animal population by stage using your configured kg per animal per day.
                        </p>
                    </div>

                    <div class="panel-body">
                        <div class="setup-list">
                            <?php $__currentLoopData = $feedSetup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage => $kgDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(str_ends_with($stage, 'kg_day')): ?>
                                    <div class="setup-pill">
                                        <span class="setup-pill-label"><?php echo e(Str::title(str_replace(['_kg_day','_'],['', ' '], $stage))); ?></span>
                                        <span class="setup-pill-value"><?php echo e($kgDay); ?></span>
                                        <span class="setup-pill-sub">kg / animal / day</span>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="panel-grid-2" x-data="{ tab: 'daily' }">
                            <div class="table-card" style="grid-column: 1 / -1;">
                                <div class="tab-head">
                                    <h3 class="tab-title">Projected Feed Requirement</h3>

                                    <div class="tab-switch">
                                        <button type="button" :class="{ 'is-active': tab === 'daily' }" @click="tab = 'daily'">Daily</button>
                                        <button type="button" :class="{ 'is-active': tab === 'weekly' }" @click="tab = 'weekly'">Weekly</button>
                                        <button type="button" :class="{ 'is-active': tab === 'monthly' }" @click="tab = 'monthly'">Monthly</button>
                                    </div>
                                </div>

                                <div x-show="tab === 'daily'">
                                    <div class="table-wrap">
                                        <table class="data-table">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th class="center">Piglets (kg)</th>
                                                    <th class="center">Weaners (kg)</th>
                                                    <th class="center">Growers (kg)</th>
                                                    <th class="center">Finishers (kg)</th>
                                                    <th class="center">Preg. Sows (kg)</th>
                                                    <th class="num">Total (kg)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $dailyFeedPaginator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($date); ?></td>
                                                        <td class="center"><?php echo e(number_format($info['needed']['piglets'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($info['needed']['weaners'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($info['needed']['growers'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($info['needed']['finishers'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($info['needed']['pregnant_sows'] ?? 0, 1)); ?></td>
                                                        <td class="num"><strong><?php echo e(number_format($info['needed']['total'] ?? 0, 1)); ?></strong></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="7" class="muted-empty">No daily projection data.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="pagination-row">
                                        <span>
                                            Showing <?php echo e($dailyFeedPaginator->firstItem()); ?> to <?php echo e($dailyFeedPaginator->lastItem()); ?> of <?php echo e($dailyFeedPaginator->total()); ?> days
                                        </span>
                                        <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $dailyFeedPaginator]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dailyFeedPaginator)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                    </div>
                                </div>

                                <div x-show="tab === 'weekly'">
                                    <div class="table-wrap">
                                        <table class="data-table">
                                            <thead>
                                                <tr>
                                                    <th>Week</th>
                                                    <th class="center">Piglets (kg)</th>
                                                    <th class="center">Weaners (kg)</th>
                                                    <th class="center">Growers (kg)</th>
                                                    <th class="center">Finishers (kg)</th>
                                                    <th class="center">Preg. Sows (kg)</th>
                                                    <th class="num">Total (kg)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $weeklyFeedPaginator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week => $totals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($week); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['piglets'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['weaners'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['growers'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['finishers'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['pregnant_sows'] ?? 0, 1)); ?></td>
                                                        <td class="num"><strong><?php echo e(number_format($totals['total'] ?? 0, 1)); ?></strong></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="7" class="muted-empty">No weekly projection data.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="pagination-row">
                                        <span>
                                            Showing <?php echo e($weeklyFeedPaginator->firstItem()); ?> to <?php echo e($weeklyFeedPaginator->lastItem()); ?> of <?php echo e($weeklyFeedPaginator->total()); ?> weeks
                                        </span>
                                        <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $weeklyFeedPaginator]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($weeklyFeedPaginator)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                    </div>
                                </div>

                                <div x-show="tab === 'monthly'">
                                    <div class="table-wrap">
                                        <table class="data-table">
                                            <thead>
                                                <tr>
                                                    <th>Month</th>
                                                    <th class="center">Piglets (kg)</th>
                                                    <th class="center">Weaners (kg)</th>
                                                    <th class="center">Growers (kg)</th>
                                                    <th class="center">Finishers (kg)</th>
                                                    <th class="center">Preg. Sows (kg)</th>
                                                    <th class="num">Total (kg)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $monthlyFeedPaginator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $totals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($month); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['piglets'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['weaners'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['growers'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['finishers'] ?? 0, 1)); ?></td>
                                                        <td class="center"><?php echo e(number_format($totals['pregnant_sows'] ?? 0, 1)); ?></td>
                                                        <td class="num"><strong><?php echo e(number_format($totals['total'] ?? 0, 1)); ?></strong></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="7" class="muted-empty">No monthly projection data.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="pagination-row">
                                        <span>
                                            Showing <?php echo e($monthlyFeedPaginator->firstItem()); ?> to <?php echo e($monthlyFeedPaginator->lastItem()); ?> of <?php echo e($monthlyFeedPaginator->total()); ?> months
                                        </span>
                                        <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $monthlyFeedPaginator]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($monthlyFeedPaginator)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="panel">
                    <div class="panel-head">
                        <h2 class="panel-title">Ideal Ingredient Requirement</h2>
                        <p class="panel-text">
                            Ingredient needs are projected from the ideal feed requirement, then expanded through mapped feed type recipes and ingredient bag sizes.
                        </p>
                    </div>

                    <div class="panel-body">
                        <?php if(!empty($missingStageFeedTypes ?? [])): ?>
                            <div class="mini-note">
                                <strong>Setup needed:</strong>
                                Some stages do not yet have feed types selected for projection:
                                <span style="font-family: ui-monospace, SFMono-Regular, Menlo, monospace;"><?php echo e(implode(', ', $missingStageFeedTypes)); ?></span>.
                                Update them in <strong>Settings → Breeding Cycle → Feed Projection Setup</strong>.
                            </div>
                        <?php endif; ?>

                        <div class="split-grid">
                            <div class="table-card">
                                <div class="table-head">
                                    <h4>Weekly Ingredients</h4>
                                </div>

                                <div class="table-wrap">
                                    <table class="data-table">
                                        <thead>
                                            <tr>
                                                <th>Week</th>
                                                <th>Ingredient</th>
                                                <th class="num">Kg</th>
                                                <th class="num">Bags</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = ($ingredientWeeklyIdealTotals ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php
                                                    $weekKgTotal = collect($rows)->sum(fn($r) => (float)($r['kg'] ?? 0));
                                                    $weekBagTotal = collect($rows)->sum(fn($r) => (float)($r['bags'] ?? 0));
                                                ?>

                                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingName => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($week); ?></td>
                                                        <td><strong><?php echo e($ingName); ?></strong></td>
                                                        <td class="num"><?php echo e(number_format((float)($row['kg'] ?? 0), 1)); ?></td>
                                                        <td class="num">
                                                            <?php if(isset($row['bags']) && $row['bags'] !== null): ?>
                                                                <?php echo e(number_format((int) ceil((float) $row['bags']), 0)); ?>

                                                            <?php else: ?>
                                                                —
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <tr class="row-total">
                                                    <td colspan="2">Total for <?php echo e($week); ?></td>
                                                    <td class="num"><?php echo e(number_format($weekKgTotal, 1)); ?> kg</td>
                                                    <td class="num"><?php echo e($weekBagTotal ? number_format((int) ceil($weekBagTotal), 0) : '0'); ?> bags</td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="4" class="muted-empty">No weekly ingredient projection data.</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="table-card">
                                <div class="table-head">
                                    <h4>Monthly Ingredients</h4>
                                </div>

                                <div class="table-wrap">
                                    <table class="data-table">
                                        <thead>
                                            <tr>
                                                <th>Month</th>
                                                <th>Ingredient</th>
                                                <th class="num">Kg</th>
                                                <th class="num">Bags</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = ($ingredientMonthlyIdealTotals ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php
                                                    $monthKgTotal = collect($rows)->sum(fn($r) => (float)($r['kg'] ?? 0));
                                                    $monthBagTotal = collect($rows)->sum(fn($r) => (float)($r['bags'] ?? 0));
                                                ?>

                                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingName => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($month); ?></td>
                                                        <td><strong><?php echo e($ingName); ?></strong></td>
                                                        <td class="num"><?php echo e(number_format((float)($row['kg'] ?? 0), 1)); ?></td>
                                                        <td class="num">
                                                            <?php if(isset($row['bags']) && $row['bags'] !== null): ?>
                                                                <?php echo e(number_format((int) ceil((float) $row['bags']), 0)); ?>

                                                            <?php else: ?>
                                                                —
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <tr class="row-total">
                                                    <td colspan="2">Total for <?php echo e($month); ?></td>
                                                    <td class="num"><?php echo e(number_format($monthKgTotal, 1)); ?> kg</td>
                                                    <td class="num"><?php echo e($monthBagTotal ? number_format((int) ceil($monthBagTotal), 0) : '0'); ?> bags</td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="4" class="muted-empty">No monthly ingredient projection data.</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="split-grid">
                    <div class="tab-card" x-data="{ tab: 'daily' }">
                        <div class="tab-head">
                            <h3 class="tab-title">Structure Consumption</h3>
                            <div class="tab-switch">
                                <button type="button" :class="{ 'is-active': tab === 'daily' }" @click="tab = 'daily'">Daily</button>
                                <button type="button" :class="{ 'is-active': tab === 'weekly' }" @click="tab = 'weekly'">Weekly</button>
                                <button type="button" :class="{ 'is-active': tab === 'monthly' }" @click="tab = 'monthly'">Monthly</button>
                            </div>
                        </div>

                        <div x-show="tab === 'daily'">
                            <div class="table-wrap" style="max-height: 350px;">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Structure</th>
                                            <th class="num">Kg</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $structureDailyPaginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php $periodTotal = collect($rows)->sum('total'); ?>
                                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($date); ?></td>
                                                    <td><strong><?php echo e($row['structure_name']); ?></strong></td>
                                                    <td class="num"><?php echo e(number_format($row['total'], 2)); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="row-total">
                                                <td>Total for <?php echo e($date); ?></td>
                                                <td></td>
                                                <td class="num"><?php echo e(number_format($periodTotal, 2)); ?> kg</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3" class="muted-empty">No daily data.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php if($structureDailyPaginated->hasPages()): ?>
                                <div class="pagination-row">
                                    <span>
                                        <?php if($structureDailyPaginated->total()): ?>
                                            Showing <?php echo e($structureDailyPaginated->firstItem()); ?> to <?php echo e($structureDailyPaginated->lastItem()); ?> of <?php echo e($structureDailyPaginated->total()); ?> days
                                        <?php else: ?>
                                            Showing 0 records
                                        <?php endif; ?>
                                    </span>
                                    <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $structureDailyPaginated]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($structureDailyPaginated)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div x-show="tab === 'weekly'">
                            <div class="table-wrap" style="max-height: 350px;">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Week</th>
                                            <th>Structure</th>
                                            <th class="num">Kg</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $structureWeeklyPaginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php $periodTotal = collect($rows)->sum('total'); ?>
                                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($week); ?></td>
                                                    <td><strong><?php echo e($row['structure_name']); ?></strong></td>
                                                    <td class="num"><?php echo e(number_format($row['total'], 2)); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="row-total">
                                                <td>Total for <?php echo e($week); ?></td>
                                                <td></td>
                                                <td class="num"><?php echo e(number_format($periodTotal, 2)); ?> kg</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3" class="muted-empty">No weekly data.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php if($structureWeeklyPaginated->hasPages()): ?>
                                <div class="pagination-row">
                                    <span>
                                        <?php if($structureWeeklyPaginated->total()): ?>
                                            Showing <?php echo e($structureWeeklyPaginated->firstItem()); ?> to <?php echo e($structureWeeklyPaginated->lastItem()); ?> of <?php echo e($structureWeeklyPaginated->total()); ?> weeks
                                        <?php else: ?>
                                            Showing 0 records
                                        <?php endif; ?>
                                    </span>
                                    <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $structureWeeklyPaginated]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($structureWeeklyPaginated)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div x-show="tab === 'monthly'">
                            <div class="table-wrap" style="max-height: 350px;">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Month</th>
                                            <th>Structure</th>
                                            <th class="num">Kg</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $structureMonthlyPaginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php $periodTotal = collect($rows)->sum('total'); ?>
                                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($month); ?></td>
                                                    <td><strong><?php echo e($row['structure_name']); ?></strong></td>
                                                    <td class="num"><?php echo e(number_format($row['total'], 2)); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="row-total">
                                                <td>Total for <?php echo e($month); ?></td>
                                                <td></td>
                                                <td class="num"><?php echo e(number_format($periodTotal, 2)); ?> kg</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3" class="muted-empty">No monthly data.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php if($structureMonthlyPaginated->hasPages()): ?>
                                <div class="pagination-row">
                                    <span>
                                        <?php if($structureMonthlyPaginated->total()): ?>
                                            Showing <?php echo e($structureMonthlyPaginated->firstItem()); ?> to <?php echo e($structureMonthlyPaginated->lastItem()); ?> of <?php echo e($structureMonthlyPaginated->total()); ?> months
                                        <?php else: ?>
                                            Showing 0 records
                                        <?php endif; ?>
                                    </span>
                                    <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $structureMonthlyPaginated]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($structureMonthlyPaginated)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="tab-card" x-data="{ tab: 'daily' }">
                        <div class="tab-head">
                            <h3 class="tab-title">Room Consumption</h3>
                            <div class="tab-switch">
                                <button type="button" :class="{ 'is-active': tab === 'daily' }" @click="tab = 'daily'">Daily</button>
                                <button type="button" :class="{ 'is-active': tab === 'weekly' }" @click="tab = 'weekly'">Weekly</button>
                                <button type="button" :class="{ 'is-active': tab === 'monthly' }" @click="tab = 'monthly'">Monthly</button>
                            </div>
                        </div>

                        <div x-show="tab === 'daily'">
                            <div class="table-wrap" style="max-height: 350px;">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Room</th>
                                            <th class="num">Kg</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $roomDailyPaginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php $periodTotal = collect($rows)->sum('total'); ?>
                                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($date); ?></td>
                                                    <td><strong><?php echo e($row['room_name']); ?></strong></td>
                                                    <td class="num"><?php echo e(number_format($row['total'], 2)); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="row-total">
                                                <td>Total for <?php echo e($date); ?></td>
                                                <td></td>
                                                <td class="num"><?php echo e(number_format($periodTotal, 2)); ?> kg</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3" class="muted-empty">No daily data.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php if($roomDailyPaginated->hasPages()): ?>
                                <div class="pagination-row">
                                    <span>
                                        <?php if($roomDailyPaginated->total()): ?>
                                            Showing <?php echo e($roomDailyPaginated->firstItem()); ?> to <?php echo e($roomDailyPaginated->lastItem()); ?> of <?php echo e($roomDailyPaginated->total()); ?> days
                                        <?php else: ?>
                                            Showing 0 records
                                        <?php endif; ?>
                                    </span>
                                    <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $roomDailyPaginated]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($roomDailyPaginated)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div x-show="tab === 'weekly'">
                            <div class="table-wrap" style="max-height: 350px;">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Week</th>
                                            <th>Room</th>
                                            <th class="num">Kg</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $roomWeeklyPaginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php $periodTotal = collect($rows)->sum('total'); ?>
                                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($week); ?></td>
                                                    <td><strong><?php echo e($row['room_name']); ?></strong></td>
                                                    <td class="num"><?php echo e(number_format($row['total'], 2)); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="row-total">
                                                <td>Total for <?php echo e($week); ?></td>
                                                <td></td>
                                                <td class="num"><?php echo e(number_format($periodTotal, 2)); ?> kg</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3" class="muted-empty">No weekly data.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php if($roomWeeklyPaginated->hasPages()): ?>
                                <div class="pagination-row">
                                    <span>
                                        <?php if($roomWeeklyPaginated->total()): ?>
                                            Showing <?php echo e($roomWeeklyPaginated->firstItem()); ?> to <?php echo e($roomWeeklyPaginated->lastItem()); ?> of <?php echo e($roomWeeklyPaginated->total()); ?> weeks
                                        <?php else: ?>
                                            Showing 0 records
                                        <?php endif; ?>
                                    </span>
                                    <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $roomWeeklyPaginated]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($roomWeeklyPaginated)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div x-show="tab === 'monthly'">
                            <div class="table-wrap" style="max-height: 350px;">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Month</th>
                                            <th>Room</th>
                                            <th class="num">Kg</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $roomMonthlyPaginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php $periodTotal = collect($rows)->sum('total'); ?>
                                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($month); ?></td>
                                                    <td><strong><?php echo e($row['room_name']); ?></strong></td>
                                                    <td class="num"><?php echo e(number_format($row['total'], 2)); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="row-total">
                                                <td>Total for <?php echo e($month); ?></td>
                                                <td></td>
                                                <td class="num"><?php echo e(number_format($periodTotal, 2)); ?> kg</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3" class="muted-empty">No monthly data.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php if($roomMonthlyPaginated->hasPages()): ?>
                                <div class="pagination-row">
                                    <span>
                                        <?php if($roomMonthlyPaginated->total()): ?>
                                            Showing <?php echo e($roomMonthlyPaginated->firstItem()); ?> to <?php echo e($roomMonthlyPaginated->lastItem()); ?> of <?php echo e($roomMonthlyPaginated->total()); ?> months
                                        <?php else: ?>
                                            Showing 0 records
                                        <?php endif; ?>
                                    </span>
                                    <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $roomMonthlyPaginated]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($roomMonthlyPaginated)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>

                <section class="chart-panel">
                    <h3 class="chart-title">Consumption Trends vs. Growth</h3>
                    <p class="chart-text">Compare feed consumed over time against average pig weight to observe growth and intake patterns.</p>

                    <div class="chart-box">
                        <canvas id="feedWeightChart"></canvas>
                    </div>
                </section>

            </div>
        </div>
    </div>

    <div id="reportDetailModal" class="report-modal" aria-hidden="true">
        <div class="report-modal-card" role="dialog" aria-modal="true" aria-labelledby="reportDetailModalTitle">
            <div class="report-modal-head">
                <div>
                    <h3 id="reportDetailModalTitle" class="report-modal-title">Card Details</h3>
                    <p id="reportDetailModalSub" class="report-modal-sub">More information</p>
                </div>
                <button type="button" class="report-modal-close" id="reportDetailModalClose">✕</button>
            </div>

            <div class="report-modal-body">
                <div id="reportModalHighlight"></div>
                <div id="reportModalStats"></div>
                <div id="reportModalBlocks" class="modal-copy"></div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal968de545b91fcc58d7756a37a6904e98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal968de545b91fcc58d7756a37a6904e98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.copyright-minimal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('copyright-minimal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $attributes = $__attributesOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__attributesOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $component = $__componentOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__componentOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        Chart.defaults.font.family = '"Inter", "system-ui", sans-serif';
        Chart.defaults.color = '#64748b';
        Chart.defaults.font.size = 11;

        const feedWeightCanvas = document.getElementById('feedWeightChart');

        if (feedWeightCanvas) {
            const feedWeightCtx = feedWeightCanvas.getContext('2d');
            const gradientFeed = feedWeightCtx.createLinearGradient(0, 0, 0, 320);
            gradientFeed.addColorStop(0, 'rgba(37, 99, 235, 0.16)');
            gradientFeed.addColorStop(1, 'rgba(37, 99, 235, 0)');

            new Chart(feedWeightCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(($feedByDate ?? collect())->keys(), 15, 512) ?>,
                    datasets: [
                        {
                            label: 'Feed (kg)',
                            data: <?php echo json_encode(($feedByDate ?? collect())->values(), 15, 512) ?>,
                            yAxisID: 'y',
                            borderColor: '#2563eb',
                            backgroundColor: gradientFeed,
                            borderWidth: 2,
                            pointRadius: 0,
                            pointHoverRadius: 5,
                            pointBackgroundColor: '#2563eb',
                            pointBorderColor: '#ffffff',
                            pointBorderWidth: 2,
                            fill: true,
                            tension: 0.35
                        },
                        {
                            label: 'Avg Weight (kg)',
                            data: <?php echo json_encode(($avgWeightByDate ?? collect())->values(), 15, 512) ?>,
                            yAxisID: 'y1',
                            borderColor: '#059669',
                            backgroundColor: 'transparent',
                            borderWidth: 2,
                            borderDash: [6, 6],
                            pointRadius: 0,
                            pointHoverRadius: 5,
                            pointBackgroundColor: '#059669',
                            pointBorderColor: '#ffffff',
                            pointBorderWidth: 2,
                            fill: false,
                            tension: 0.35
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        mode: 'index',
                        intersect: false
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                            align: 'end',
                            labels: {
                                usePointStyle: true,
                                boxWidth: 8
                            }
                        },
                        tooltip: {
                            backgroundColor: '#0f172a',
                            padding: 12,
                            cornerRadius: 10
                        }
                    },
                    scales: {
                        x: {
                            grid: { display: false },
                            border: { display: false },
                            ticks: {
                                autoSkip: true,
                                maxTicksLimit: 8
                            }
                        },
                        y: {
                            position: 'left',
                            title: {
                                display: true,
                                text: 'Feed Consumed (kg)'
                            },
                            grid: {
                                color: '#eef2f7'
                            },
                            border: { display: false }
                        },
                        y1: {
                            position: 'right',
                            title: {
                                display: true,
                                text: 'Pig Weight (kg)'
                            },
                            grid: {
                                display: false
                            },
                            border: { display: false }
                        }
                    }
                }
            });
        }

        document.addEventListener('DOMContentLoaded', function () {
            const modal = document.getElementById('reportDetailModal');
            const modalClose = document.getElementById('reportDetailModalClose');
            const modalTitle = document.getElementById('reportDetailModalTitle');
            const modalSub = document.getElementById('reportDetailModalSub');
            const modalHighlight = document.getElementById('reportModalHighlight');
            const modalStats = document.getElementById('reportModalStats');
            const modalBlocks = document.getElementById('reportModalBlocks');

            function renderModalContent(payload) {
                modalHighlight.innerHTML = `
                    <div class="modal-highlight">
                        <div class="modal-highlight-label">${payload.highlight_label ?? ''}</div>
                        <div class="modal-highlight-value">${payload.highlight_value ?? ''}</div>
                        <div class="modal-highlight-sub">${payload.highlight_sub ?? ''}</div>
                    </div>
                `;

                const stats = Array.isArray(payload.stats) ? payload.stats : [];
                modalStats.innerHTML = stats.length ? `
                    <div class="modal-grid">
                        ${stats.map(stat => `
                            <div class="modal-stat">
                                <span class="modal-stat-label">${stat.label ?? ''}</span>
                                <span class="modal-stat-value">${stat.value ?? ''}</span>
                            </div>
                        `).join('')}
                    </div>
                ` : '';

                const blocks = Array.isArray(payload.blocks) ? payload.blocks : [];
                modalBlocks.innerHTML = blocks.map(block => `
                    <div class="modal-copy-block">
                        <h4 class="modal-copy-title">${block.title ?? ''}</h4>
                        <p class="modal-copy-text">${block.text ?? ''}</p>
                    </div>
                `).join('');
            }

            function openModal(title, sub, payload) {
                modalTitle.textContent = title || 'Card Details';
                modalSub.textContent = sub || 'More information';
                renderModalContent(payload || {});
                modal.classList.add('is-open');
                modal.setAttribute('aria-hidden', 'false');
                document.body.style.overflow = 'hidden';
            }

            function closeModal() {
                modal.classList.remove('is-open');
                modal.setAttribute('aria-hidden', 'true');
                document.body.style.overflow = '';
            }

            document.querySelectorAll('.metric-clickable').forEach(card => {
                card.addEventListener('click', function () {
                    const title = this.getAttribute('data-modal-title');
                    const sub = this.getAttribute('data-modal-sub');
                    const payload = JSON.parse(this.getAttribute('data-modal-content') || '{}');
                    openModal(title, sub, payload);
                });

                card.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        this.click();
                    }
                });

                card.setAttribute('tabindex', '0');
            });

            modalClose.addEventListener('click', closeModal);

            modal.addEventListener('click', function (e) {
                if (e.target === modal) {
                    closeModal();
                }
            });

            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && modal.classList.contains('is-open')) {
                    closeModal();
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/charlotte/chipper-farms/resources/views/feeds/reports.blade.php ENDPATH**/ ?>