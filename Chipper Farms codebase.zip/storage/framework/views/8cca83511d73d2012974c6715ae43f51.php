<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="flex items-center justify-between mb-4">
                <h1 class="text-xl font-semibold text-gray-900">Structures</h1>
                <a href="<?php echo e(route('structures.create')); ?>" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">New Structure</a>
            </div>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Capacity</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__empty_1 = true; $__currentLoopData = $structures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $structure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <div>
                                            <div class="font-medium"><?php echo e($structure->name); ?></div>
                                            <?php if($structure->code): ?>
                                                <div class="text-xs text-gray-500">Code: <?php echo e($structure->code); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <div class="max-w-xs truncate" title="<?php echo e($structure->description); ?>">
                                            <?php echo e($structure->description ?? 'N/A'); ?>

                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php if($structure->capacity): ?>
                                            <?php echo e($structure->current_room_count); ?>/<?php echo e($structure->capacity); ?>

                                            <?php if($structure->is_full): ?>
                                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 ml-2">Full</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php echo e($structure->current_room_count); ?> (Unlimited)
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="text-sm font-medium text-gray-900">
                                         <?php echo e(ucfirst($structure->status)); ?>

                                        </span>
                                    </td>

                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="<?php echo e(route('structures.show', $structure)); ?>" class="text-blue-600 hover:text-blue-900">View</a>
                                        <form action="<?php echo e(route('structures.destroy', $structure)); ?>" method="POST" onsubmit="return confirm('Delete this structure?');" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-600 hover:text-red-900">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="px-6 py-12 text-center text-gray-500">No structures found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if($structures->hasPages()): ?>
                    <div class="px-6 py-4">
                        <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $structures]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($structures)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal968de545b91fcc58d7756a37a6904e98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal968de545b91fcc58d7756a37a6904e98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.copyright-minimal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('copyright-minimal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $attributes = $__attributesOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__attributesOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $component = $__componentOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__componentOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>


<?php /**PATH /home/charlotte/chipper-farms/resources/views/structures/index.blade.php ENDPATH**/ ?>