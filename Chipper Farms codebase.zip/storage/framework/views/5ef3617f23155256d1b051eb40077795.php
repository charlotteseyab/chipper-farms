<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <main class="flex-1 p-8">
        <div class="max-w-6xl mx-auto">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-bold text-blue-700">Standard Stock Management</h2>
                <!-- <a href="<?php echo e(route('standard-stocks.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700">Add New</a> -->
            </div>

            <div class="bg-white shadow-xl rounded-lg">
                <!-- Filters and Export Buttons integrated with table -->
                <div class="p-6 border-b border-gray-200">
                    <form method="GET" action="<?php echo e(route('standard-stocks.index')); ?>" id="filterForm" class="flex flex-wrap items-end gap-4 mb-4">
                        <div class="flex-1 min-w-[200px]">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Breed</label>
                            <select name="breed" id="breedFilter" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-600 focus:border-blue-600">
                                <option value="" disabled selected>All Breeds</option>
                                <option value="LW" <?php echo e(request('breed') == 'LW' ? 'selected' : ''); ?>>Large White</option>
                                <option value="DR" <?php echo e(request('breed') == 'DR' ? 'selected' : ''); ?>>Duroc</option>
                                <option value="LWDR" <?php echo e(request('breed') == 'LWDR' ? 'selected' : ''); ?>>Large White Duroc</option>
                            </select>
                        </div>
                        <div class="flex-1 min-w-[150px]">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Gender</label>
                            <select name="gender" id="genderFilter" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-600 focus:border-blue-600">
                                <option value="" disabled selected>All Genders</option>
                                <option value="M" <?php echo e(request('gender') == 'M' ? 'selected' : ''); ?>>Male</option>
                                <option value="F" <?php echo e(request('gender') == 'F' ? 'selected' : ''); ?>>Female</option>
                            </select>
                        </div>
                        <div class="flex-1 min-w-[150px]">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Min Age (days)</label>
                            <input type="number" name="age" id="ageFilter" value="<?php echo e(request('age')); ?>" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-600 focus:border-blue-600" placeholder="e.g. 365">
                        </div>
                        <div class="flex gap-2">
                            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Filter</button>
                            <a href="<?php echo e(route('standard-stocks.index')); ?>" class="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 font-medium">Clear</a>
                        </div>
                    </form>
                    
                    <!-- Export Buttons -->
                    <div class="flex gap-2">
                        <a href="<?php echo e(route('standard-stocks.export.csv', request()->query())); ?>" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2 font-medium">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            Export CSV
                        </a>
                        <a href="<?php echo e(route('standard-stocks.export.pdf', request()->query())); ?>" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 flex items-center gap-2 font-medium">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            Export PDF
                        </a>
                    </div>
                </div>
                
                <!-- Results Summary -->
                <div class="px-6 py-3 bg-blue-50 border-b border-gray-200">
                    <div class="flex items-center justify-between">
                        <div class="text-sm text-blue-700">
                            <?php if($pigmanagement->total() > 0): ?>
                                Total: <?php echo e($pigmanagement->total()); ?> standard pig<?php echo e($pigmanagement->total() !== 1 ? 's' : ''); ?>

                                <?php if(request()->hasAny(['breed', 'gender', 'age'])): ?>
                                    (filtered)
                                <?php endif; ?>
                            <?php else: ?>
                                No standard pigs found
                            <?php endif; ?>
                        </div>
                        <?php if($pigmanagement->hasPages()): ?>
                        <!-- <div class="text-sm text-blue-700">
                            Page <?php echo e($pigmanagement->currentPage()); ?> of <?php echo e($pigmanagement->lastPage()); ?>

                        </div> -->
                        <?php endif; ?>
                    </div>
                </div>
                
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-blue-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-blue-700 uppercase tracking-wider">Code</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-blue-700 uppercase tracking-wider">Ear tag</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-blue-700 uppercase tracking-wider">Breed</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-blue-700 uppercase tracking-wider">Gender</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-blue-700 uppercase tracking-wider">Age</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-blue-700 uppercase tracking-wider">Breeding Ready</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-blue-700 uppercase tracking-wider">Sale Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-blue-700 uppercase tracking-wider">Parents</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-blue-700 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $pigmanagement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $readiness = $pig->breeding_readiness;
                            $saleEligibility = $pig->sale_eligibility;
                            $saleStatus = $pig->sale_status;
                        ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($pig->code); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($pig->ear_tag_number); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($pig->breed); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap capitalize"><?php echo e($pig->gender); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap" title="<?php echo e($pig->current_age_in_days); ?> days">
                                <?php echo e($pig->age_compact); ?>

                                <?php if($pig->current_age_in_days < 0): ?>
                                    <span class="text-red-500 text-xs">(Invalid)</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex flex-col space-y-1">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium <?php echo e($pig->breeding_readiness_badge); ?>">
                                        <?php if($readiness['age_status'] === 'optimal'): ?>
                                            ✓ Optimal
                                        <?php elseif($readiness['age_status'] === 'minimum_met'): ?>
                                            ⚠ Ready
                                        <?php elseif($readiness['age_status'] === 'too_young'): ?>
                                            ⏳ Too Young
                                        <?php elseif($readiness['age_status'] === 'too_old'): ?>
                                            🛑 Too Old
                                        <?php endif; ?>
                                    </span>
                                    <?php if($readiness['factors']['weight']['status'] !== 'not_checked'): ?>
                                        <span class="text-xs text-gray-500">
                                            Weight: <?php echo e($readiness['factors']['weight']['status'] === 'optimal' ? '✓' : ($readiness['factors']['weight']['status'] === 'minimum_met' ? '⚠' : '✗')); ?>

                                            <?php if($pig->latestWeight): ?>
                                                <?php echo e($pig->latestWeight->formatted_weight); ?>

                                            <?php endif; ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-xs text-gray-400">No weight data</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium <?php echo e($saleStatus['badge_class']); ?>">
                                     <?php echo e(ucfirst($saleStatus['status'])); ?>

                                </span>
                                <?php if($saleStatus['sold']): ?>
                                    <p class="text-xs text-gray-500 mt-1"><?php echo e($saleStatus['sale_price']); ?></p>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php
                                    $father = $pig->father_id ? $pig->father->ear_tag_number ?? 'N/A' : 'N/A';
                                    $mother = $pig->mother_id ? $pig->mother->ear_tag_number ?? 'N/A' : 'N/A';
                                ?>
                                F: <?php echo e($father); ?><br>M: <?php echo e($mother); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="relative" x-data="{ open: false }">
                                    <button @click="open = !open" class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        Actions
                                        <svg class="ml-2 -mr-0.5 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                        </svg>
                                    </button>
                                    
                                    <div x-show="open" @click.away="open = false" x-transition:enter="transition ease-out duration-100" x-transition:enter-start="transform opacity-0 scale-95" x-transition:enter-end="transform opacity-100 scale-100" x-transition:leave="transition ease-in duration-75" x-transition:leave-start="transform opacity-100 scale-100" x-transition:leave-end="transform opacity-0 scale-95" class="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                                        <div class="py-1">
                                            <!-- View -->
                                            <a href="<?php echo e(route('pigs.show', $pig->id)); ?>" class="group flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                <svg class="mr-3 h-4 w-4 text-gray-400 group-hover:text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                                                </svg>
                                                View Details
                                            </a>
                                            
                                            <?php if(!$saleStatus['sold']): ?>
                                                <!-- Edit -->
                                                <a href="<?php echo e(route('standard-stocks.edit', $pig->id)); ?>" class="group flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                    <svg class="mr-3 h-4 w-4 text-gray-400 group-hover:text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                                    </svg>
                                                    Edit
                                                </a>
                                                
                                                <!-- Promote to Breeding -->
                                                <?php if(in_array($readiness['age_status'], ['minimum_met', 'optimal']) && $readiness['factors']['weight']['status'] !== 'too_light'): ?>
                                                    <form action="<?php echo e(route('pigs.promote-to-breeding', $pig->id)); ?>" method="POST" onsubmit="return confirm('Promote <?php echo e($pig->code); ?> to breeding stock?');" class="block">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="group flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-left">
                                                            <svg class="mr-3 h-4 w-4 text-green-500 group-hover:text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 10l7-7m0 0l7 7m-7-7v18"></path>
                                                            </svg>
                                                            Promote to Breeding
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <div class="px-4 py-2 text-sm text-gray-400 cursor-not-allowed" title="<?php echo e($readiness['age_message']); ?>">
                                                        <div class="flex items-center">
                                                            <svg class="mr-3 h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                                                            </svg>
                                                            Not Ready for Promotion
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                                
                                                <!-- Record Sale -->
                                                <?php if($saleEligibility['eligible']): ?>
                                                    <a href="<?php echo e(route('pigs.sale-form', $pig->id)); ?>" class="group flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                        <svg class="mr-3 h-4 w-4 text-orange-500 group-hover:text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"/>
                                                        </svg>
                                                        Record Sale
                                                    </a>
                                                <?php else: ?>
                                                    <div class="px-4 py-2 text-sm text-gray-400 cursor-not-allowed" title="<?php echo e($saleEligibility['reason']); ?>">
                                                        <div class="flex items-center">
                                                            <span class="mr-3"><?php echo e($saleEligibility['icon']); ?></span>
                                                            Cannot Sell
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                                
                                                <!-- Divider -->
                                                <div class="border-t border-gray-100 my-1"></div>
                                                
                                                <!-- Delete -->
                                                <form action="#" method="POST" onsubmit="return confirm('Are you sure you want to delete this pig?');" class="block">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="group flex items-center w-full px-4 py-2 text-sm text-red-700 hover:bg-red-50 text-left">
                                                        <svg class="mr-3 h-4 w-4 text-red-400 group-hover:text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                        </svg>
                                                        Delete
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <!-- Sold Status -->
                                                <div class="px-4 py-2 text-sm text-blue-600 bg-blue-50">
                                                    <div class="flex items-center">
                                                        <svg class="mr-3 h-4 w-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                                        </svg>
                                                        ✅ Sold
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center justify-center">
                                    <svg class="w-12 h-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.29-1.009-5.824-2.562M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.636 6.636a9 9 0 000 12.728"></path>
                                    </svg>
                                    <h3 class="text-lg font-medium text-gray-900 mb-2">No standard stock found</h3>
                                    <p class="text-gray-500 mb-4">
                                        <?php if(request()->hasAny(['breed', 'gender', 'age'])): ?>
                                            No standard pigs match your current filter criteria. Try adjusting your filters or 
                                            <a href="<?php echo e(route('standard-stocks.index')); ?>" class="text-blue-600 hover:underline font-medium">clear all filters</a>.
                                        <?php else: ?>
                                            There are no standard stock records in the system yet.
                                        <?php endif; ?>
                                    </p>
                                    <?php if(!request()->hasAny(['breed', 'gender', 'age'])): ?>
                                    <!-- <a href="#" class="px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700">
                                        Add First Standard Stock
                                    </a> -->
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                <!-- Pagination -->
                <?php if($pigmanagement->hasPages()): ?>
                <div class="px-6 py-4 border-t border-gray-200">
                    <div class="flex items-center justify-between">
                        <div class="text-sm text-gray-700">
                            Showing <?php echo e($pigmanagement->firstItem()); ?> to <?php echo e($pigmanagement->lastItem()); ?> of <?php echo e($pigmanagement->total()); ?> results
                        </div>
                        <div class="flex items-center space-x-2">
                            <?php if (isset($component)) { $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.simple-pagination','data' => ['paginator' => $pigmanagement]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pigmanagement)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $attributes = $__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__attributesOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a)): ?>
<?php $component = $__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a; ?>
<?php unset($__componentOriginal7f00ff5afe24fdd96b080a2fca3c536a); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    <?php if (isset($component)) { $__componentOriginal968de545b91fcc58d7756a37a6904e98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal968de545b91fcc58d7756a37a6904e98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.copyright-minimal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('copyright-minimal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $attributes = $__attributesOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__attributesOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal968de545b91fcc58d7756a37a6904e98)): ?>
<?php $component = $__componentOriginal968de545b91fcc58d7756a37a6904e98; ?>
<?php unset($__componentOriginal968de545b91fcc58d7756a37a6904e98); ?>
<?php endif; ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('filterForm');
            const breedFilter = document.getElementById('breedFilter');
            const genderFilter = document.getElementById('genderFilter');
            const ageFilter = document.getElementById('ageFilter');
            
            // Add event listeners for live search
            breedFilter.addEventListener('change', function() {
                form.submit();
            });
            
            genderFilter.addEventListener('change', function() {
                form.submit();
            });
            
            // For age input, use a debounced approach to avoid too many requests
            let ageTimeout;
            ageFilter.addEventListener('input', function() {
                clearTimeout(ageTimeout);
                ageTimeout = setTimeout(function() {
                    form.submit();
                }, 500); // Wait 500ms after user stops typing
            });
            
            // Also submit on Enter key for age input
            ageFilter.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    clearTimeout(ageTimeout);
                    form.submit();
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/charlotte/chipper-farms/resources/views/stocks/standard/index.blade.php ENDPATH**/ ?>