<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Favicon -->
        <link rel="icon" type="image/svg+xml" href="/favicon.svg">
        <link rel="icon" type="image/png" sizes="32x32" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🐷</text></svg>">
        <link rel="apple-touch-icon" sizes="180x180" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🐷</text></svg>">

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <!-- Alpine.js -->
        <!-- <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script> -->

        <!-- Font Awesome CDN -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <!-- Custom Scrollbar Styles -->
        <style>
            /* Custom scrollbar for sidebars */
            .scrollbar-thin {
                scrollbar-width: thin;
            }

            .scrollbar-thin::-webkit-scrollbar {
                width: 6px;
            }

            .scrollbar-thin::-webkit-scrollbar-track {
                background: #1C6C51;
                border-radius: 3px;
            }

            .scrollbar-thin::-webkit-scrollbar-thumb {
                background: #218c6a;
                border-radius: 3px;
            }

            .scrollbar-thin::-webkit-scrollbar-thumb:hover {
                background: #2da776;
            }

            /* Ensure smooth scrolling */
            .scrollbar-thin {
                scroll-behavior: smooth;
            }
        </style>

        <!-- Styles -->
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
    <body class="font-sans antialiased">
        <?php if (isset($component)) { $__componentOriginalff9615640ecc9fe720b9f7641382872b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff9615640ecc9fe720b9f7641382872b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $attributes = $__attributesOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__attributesOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $component = $__componentOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__componentOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>

        <div class="min-h-screen bg-gray-100">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('navigation-menu');

$__html = app('livewire')->mount($__name, $__params, 'lw-622321623-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <div class="flex min-h-screen pt-16">
                <?php $user = Auth::user(); ?>
                <?php if($user && $user->isAdmin()): ?>
                    <?php if (isset($component)) { $__componentOriginal257baafdfbcbd9e6d63f040030148322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal257baafdfbcbd9e6d63f040030148322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal257baafdfbcbd9e6d63f040030148322)): ?>
<?php $attributes = $__attributesOriginal257baafdfbcbd9e6d63f040030148322; ?>
<?php unset($__attributesOriginal257baafdfbcbd9e6d63f040030148322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal257baafdfbcbd9e6d63f040030148322)): ?>
<?php $component = $__componentOriginal257baafdfbcbd9e6d63f040030148322; ?>
<?php unset($__componentOriginal257baafdfbcbd9e6d63f040030148322); ?>
<?php endif; ?>
                <?php elseif($user && $user->isManager()): ?>
                    <?php if (isset($component)) { $__componentOriginal6fcc8cd4a7beae9b1145b097e29645eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fcc8cd4a7beae9b1145b097e29645eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-manager','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-manager'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fcc8cd4a7beae9b1145b097e29645eb)): ?>
<?php $attributes = $__attributesOriginal6fcc8cd4a7beae9b1145b097e29645eb; ?>
<?php unset($__attributesOriginal6fcc8cd4a7beae9b1145b097e29645eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fcc8cd4a7beae9b1145b097e29645eb)): ?>
<?php $component = $__componentOriginal6fcc8cd4a7beae9b1145b097e29645eb; ?>
<?php unset($__componentOriginal6fcc8cd4a7beae9b1145b097e29645eb); ?>
<?php endif; ?>
                <?php elseif($user && $user->isSuperuser()): ?>
                    <?php if (isset($component)) { $__componentOriginal393f8153367c3ee07ef4c524dd72d161 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal393f8153367c3ee07ef4c524dd72d161 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-superuser','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-superuser'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal393f8153367c3ee07ef4c524dd72d161)): ?>
<?php $attributes = $__attributesOriginal393f8153367c3ee07ef4c524dd72d161; ?>
<?php unset($__attributesOriginal393f8153367c3ee07ef4c524dd72d161); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal393f8153367c3ee07ef4c524dd72d161)): ?>
<?php $component = $__componentOriginal393f8153367c3ee07ef4c524dd72d161; ?>
<?php unset($__componentOriginal393f8153367c3ee07ef4c524dd72d161); ?>
<?php endif; ?>
                <?php elseif($user && $user->isDataEntry()): ?>
                    <?php if (isset($component)) { $__componentOriginal6135cf8f45c704139e382de70b8b617e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6135cf8f45c704139e382de70b8b617e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-dataentry','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-dataentry'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6135cf8f45c704139e382de70b8b617e)): ?>
<?php $attributes = $__attributesOriginal6135cf8f45c704139e382de70b8b617e; ?>
<?php unset($__attributesOriginal6135cf8f45c704139e382de70b8b617e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6135cf8f45c704139e382de70b8b617e)): ?>
<?php $component = $__componentOriginal6135cf8f45c704139e382de70b8b617e; ?>
<?php unset($__componentOriginal6135cf8f45c704139e382de70b8b617e); ?>
<?php endif; ?>
                <?php endif; ?>

                <div class="flex-1 ml-72 mt-4">
                    <!-- Page Heading -->
                    <?php if(isset($header)): ?>
                        <header class="bg-white shadow">
                            <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                                <?php echo e($header); ?>

                            </div>
                        </header>
                    <?php endif; ?>

                    <!-- Page Content -->
                    <main>
                        <!-- Global Flash Messages -->
                        <div class="flash-messages" x-data="{
                            init() {
                                // Add keyboard support for closing messages
                                document.addEventListener('keydown', (e) => {
                                    if (e.key === 'Escape') {
                                        // Close all visible messages
                                        this.$el.querySelectorAll('[x-data]').forEach(el => {
                                            if (el.__x && el.__x.$data.show) {
                                                el.__x.$data.show = false;
                                            }
                                        });
                                    }
                                });
                            }
                        }">
                            <!-- Close All Button (shows when multiple messages exist) -->
                            <?php
                                $messageCount = collect(['success', 'error', 'warning', 'info'])->filter(fn($type) => session($type))->count();
                                $messageCount += $errors->any() ? 1 : 0;
                            ?>

                            <?php if($messageCount > 1): ?>
                                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
                                    <div class="flex justify-end">
                                        <button @click="$el.closest('.flash-messages').querySelectorAll('[x-data]').forEach(el => { if (el.__x && el.__x.$data.show) el.__x.$data.show = false; })"
                                                class="inline-flex items-center px-3 py-1 text-xs font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2">
                                            <svg class="h-3 w-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                            </svg>
                                            Close All Messages
                                        </button>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(session('success')): ?>
                                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
                                    <div class="bg-green-50 border border-green-200 rounded-lg p-4 shadow-sm"
                                         x-data="{ show: true }"
                                         x-show="show"
                                         x-transition:enter="transition ease-out duration-300"
                                         x-transition:enter-start="opacity-0 transform scale-95"
                                         x-transition:enter-end="opacity-100 transform scale-100"
                                         x-transition:leave="transition ease-in duration-200"
                                         x-transition:leave-start="opacity-100 transform scale-100"
                                         x-transition:leave-end="opacity-0 transform scale-95">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center">
                                                <svg class="h-5 w-5 text-green-600 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                                </svg>
                                                <span class="text-green-800 font-medium"><?php echo e(session('success')); ?></span>
                                            </div>
                                            <button @click="show = false"
                                                    class="ml-4 flex-shrink-0 text-green-600 hover:text-green-800 hover:bg-green-100 rounded-full p-1 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                                                    aria-label="Close message">
                                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
                                    <div class="bg-red-50 border border-red-200 rounded-lg p-4 shadow-sm"
                                         x-data="{ show: true }"
                                         x-show="show"
                                         x-transition:enter="transition ease-out duration-300"
                                         x-transition:enter-start="opacity-0 transform scale-95"
                                         x-transition:enter-end="opacity-100 transform scale-100"
                                         x-transition:leave="transition ease-in duration-200"
                                         x-transition:leave-start="opacity-100 transform scale-100"
                                         x-transition:leave-end="opacity-0 transform scale-95">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center">
                                                <svg class="h-5 w-5 text-red-600 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                                </svg>
                                                <span class="text-red-800 font-medium"><?php echo e(session('error')); ?></span>
                                            </div>
                                            <button @click="show = false"
                                                    class="ml-4 flex-shrink-0 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full p-1 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                                                    aria-label="Close message">
                                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(session('warning')): ?>
                                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
                                    <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 shadow-sm"
                                         x-data="{ show: true }"
                                         x-show="show"
                                         x-transition:enter="transition ease-out duration-300"
                                         x-transition:enter-start="opacity-0 transform scale-95"
                                         x-transition:enter-end="opacity-100 transform scale-100"
                                         x-transition:leave="transition ease-in duration-200"
                                         x-transition:leave-start="opacity-100 transform scale-100"
                                         x-transition:leave-end="opacity-0 transform scale-95">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center">
                                                <svg class="h-5 w-5 text-yellow-600 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"/>
                                                </svg>
                                                <span class="text-yellow-800 font-medium"><?php echo e(session('warning')); ?></span>
                                            </div>
                                            <button @click="show = false"
                                                    class="ml-4 flex-shrink-0 text-yellow-600 hover:text-yellow-800 hover:bg-yellow-100 rounded-full p-1 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2"
                                                    aria-label="Close message">
                                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(session('info')): ?>
                                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
                                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 shadow-sm"
                                         x-data="{ show: true }"
                                         x-show="show"
                                         x-transition:enter="transition ease-out duration-300"
                                         x-transition:enter-start="opacity-0 transform scale-95"
                                         x-transition:enter-end="opacity-100 transform scale-100"
                                         x-transition:leave="transition ease-in duration-200"
                                         x-transition:leave-start="opacity-100 transform scale-100"
                                         x-transition:leave-end="opacity-0 transform scale-95">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center">
                                                <svg class="h-5 w-5 text-blue-600 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                                </svg>
                                                <span class="text-blue-800 font-medium"><?php echo e(session('info')); ?></span>
                                            </div>
                                            <button @click="show = false"
                                                    class="ml-4 flex-shrink-0 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full p-1 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                                                    aria-label="Close message">
                                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if($errors->any()): ?>
                                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
                                    <div class="bg-red-50 border border-red-200 rounded-lg p-4 shadow-sm"
                                         x-data="{ show: true }"
                                         x-show="show"
                                         x-transition:enter="transition ease-out duration-300"
                                         x-transition:enter-start="opacity-0 transform scale-95"
                                         x-transition:enter-end="opacity-100 transform scale-100"
                                         x-transition:leave="transition ease-in duration-200"
                                         x-transition:leave-start="opacity-100 transform scale-100"
                                         x-transition:leave-end="opacity-0 transform scale-95">
                                        <div class="flex items-start justify-between">
                                            <div class="flex items-start">
                                                <svg class="h-5 w-5 text-red-600 mr-3 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                                </svg>
                                                <div class="flex-1">
                                                    <h3 class="text-red-800 font-medium mb-2">Please correct the following errors:</h3>
                                                    <ul class="list-disc list-inside text-red-700 space-y-1">
                                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li class="text-sm"><?php echo e($error); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <button @click="show = false"
                                                    class="ml-4 flex-shrink-0 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full p-1 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                                                    aria-label="Close error messages">
                                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php echo e($slot); ?>

                    </main>
                </div>
            </div>
        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

        
    </body>
</html>
<?php /**PATH /home/charlotte/chipper-farms/resources/views/layouts/app.blade.php ENDPATH**/ ?>