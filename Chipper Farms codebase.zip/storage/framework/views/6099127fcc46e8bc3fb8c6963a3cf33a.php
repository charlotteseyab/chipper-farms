<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-slate-900">Raw Materials</h1>
                    <p class="text-sm text-slate-600">Manage ingredients, stock levels and recent stock movements.</p>
                </div>

                <button
                    type="button"
                    onclick="document.getElementById('rawMaterialForm').classList.toggle('hidden')"
                    class="inline-flex items-center px-4 py-2 rounded-xl bg-[#218c6a] text-white text-sm font-medium hover:opacity-90 transition"
                >
                    Add Raw Material
                </button>
            </div>

            <?php if(session('success')): ?>
                <div class="mb-4 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-green-700 text-sm">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-red-700 text-sm">
                    <ul class="list-disc pl-5 space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div id="rawMaterialForm" class="hidden bg-white rounded-2xl border shadow-sm p-6 mb-6">
                <h2 class="text-lg font-semibold text-slate-900 mb-4">Create Raw Material</h2>

                <form action="<?php echo e(route('feed-management.raw-materials.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Material Name</label>
                            <input
                                type="text"
                                name="name"
                                value="<?php echo e(old('name')); ?>"
                                class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                required
                            >
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Code</label>
                            <input
                                type="text"
                                name="code"
                                value="<?php echo e(old('code')); ?>"
                                class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                placeholder="Optional"
                            >
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Category</label>
                            <input
                                type="text"
                                name="category"
                                value="<?php echo e(old('category')); ?>"
                                class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                placeholder="e.g. Energy, Protein, Additive"
                            >
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Unit</label>
                            <select
                                name="unit"
                                class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                required
                            >
                                <option value="kg" <?php if(old('unit') === 'kg'): echo 'selected'; endif; ?>>kg</option>
                                <option value="bags" <?php if(old('unit') === 'bags'): echo 'selected'; endif; ?>>bags</option>
                                <option value="tons" <?php if(old('unit') === 'tons'): echo 'selected'; endif; ?>>tons</option>
                                <option value="litres" <?php if(old('unit') === 'litres'): echo 'selected'; endif; ?>>litres</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Reorder Level</label>
                            <input
                                type="number"
                                step="0.01"
                                name="reorder_level"
                                value="<?php echo e(old('reorder_level', 0)); ?>"
                                class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                                required
                            >
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
                            <select
                                name="is_active"
                                class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                            >
                                <option value="1" <?php if(old('is_active', '1') == '1'): echo 'selected'; endif; ?>>Active</option>
                                <option value="0" <?php if(old('is_active') == '0'): echo 'selected'; endif; ?>>Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-medium text-slate-700 mb-1">Description</label>
                        <textarea
                            name="description"
                            rows="3"
                            class="w-full rounded-xl border-slate-300 focus:border-[#218c6a] focus:ring-[#218c6a]"
                            placeholder="Optional description"
                        ><?php echo e(old('description')); ?></textarea>
                    </div>

                    <div class="flex items-center gap-3">
                        <button
                            type="submit"
                            class="inline-flex items-center px-4 py-2 rounded-xl bg-[#218c6a] text-white text-sm font-medium hover:opacity-90 transition"
                        >
                            Save Material
                        </button>

                        <button
                            type="button"
                            onclick="document.getElementById('rawMaterialForm').classList.add('hidden')"
                            class="inline-flex items-center px-4 py-2 rounded-xl border text-sm font-medium text-slate-700 hover:bg-slate-50 transition"
                        >
                            Cancel
                        </button>
                    </div>
                </form>
            </div>

            <div class="bg-white rounded-2xl border shadow-sm overflow-hidden mb-6">
                <div class="p-5 border-b">
                    <h2 class="text-lg font-semibold">Materials List</h2>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-4 py-3 text-left">Name</th>
                                <th class="px-4 py-3 text-left">Category</th>
                                <th class="px-4 py-3 text-left">Unit</th>
                                <th class="px-4 py-3 text-left">Reorder Level</th>
                                <th class="px-4 py-3 text-left">Current Stock</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-t">
                                    <td class="px-4 py-3"><?php echo e($material->name); ?></td>
                                    <td class="px-4 py-3"><?php echo e($material->category ?? '—'); ?></td>
                                    <td class="px-4 py-3"><?php echo e($material->unit); ?></td>
                                    <td class="px-4 py-3"><?php echo e(number_format($material->reorder_level, 2)); ?></td>
                                    <td class="px-4 py-3 font-medium"><?php echo e(number_format($material->current_stock, 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="px-4 py-6 text-center text-slate-500">No raw materials found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="p-4">
                    <?php echo e($materials->links()); ?>

                </div>
            </div>

            <div class="bg-white rounded-2xl border shadow-sm overflow-hidden">
                <div class="p-5 border-b">
                    <h2 class="text-lg font-semibold">Recent Stock Movements</h2>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-4 py-3 text-left">Date</th>
                                <th class="px-4 py-3 text-left">Material</th>
                                <th class="px-4 py-3 text-left">Type</th>
                                <th class="px-4 py-3 text-left">Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-t">
                                    <td class="px-4 py-3"><?php echo e(optional($movement->movement_date)->format('d M Y')); ?></td>
                                    <td class="px-4 py-3"><?php echo e($movement->rawMaterial->name ?? '—'); ?></td>
                                    <td class="px-4 py-3"><?php echo e(str_replace('_', ' ', ucfirst($movement->movement_type))); ?></td>
                                    <td class="px-4 py-3"><?php echo e(number_format($movement->quantity, 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="px-4 py-6 text-center text-slate-500">No stock movements yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/charlotte/chipper-farms/resources/views/feed-management/raw-materials.blade.php ENDPATH**/ ?>