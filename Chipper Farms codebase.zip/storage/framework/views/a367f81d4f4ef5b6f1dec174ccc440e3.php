<div class="text-center py-3 text-xs text-gray-500 mt-6">
    <hr class="mb-4 border-t-1">
    © <?php echo e(date('Y')); ?> Chipper Farms. All rights reserved. Built with ❤️ for modern farm management. 
    <span class="font-semibold" style="color: #212A64;">| Powered by Innosol Limited.</span>
</div><?php /**PATH /home/charlotte/chipper-farms/resources/views/components/copyright-minimal.blade.php ENDPATH**/ ?>