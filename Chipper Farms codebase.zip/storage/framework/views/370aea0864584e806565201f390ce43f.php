<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-slate-900">Feed Mixing</h1>
                <p class="text-sm text-slate-600">Manage feed formulas, mix batches and produced feed.</p>
            </div>

            <div class="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
                <div class="xl:col-span-2 bg-white rounded-2xl border shadow-sm overflow-hidden">
                    <div class="p-5 border-b">
                        <h2 class="text-lg font-semibold">Feed Formulas</h2>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="min-w-full text-sm">
                            <thead class="bg-slate-50">
                                <tr>
                                    <th class="px-4 py-3 text-left">Formula</th>
                                    <th class="px-4 py-3 text-left">Animal Type</th>
                                    <th class="px-4 py-3 text-left">Stage</th>
                                    <th class="px-4 py-3 text-left">Batch Size</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $formulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border-t">
                                        <td class="px-4 py-3"><?php echo e($formula->name); ?></td>
                                        <td class="px-4 py-3"><?php echo e($formula->animal_type); ?></td>
                                        <td class="px-4 py-3"><?php echo e($formula->animalStage->name ?? '—'); ?></td>
                                        <td class="px-4 py-3"><?php echo e(number_format($formula->standard_batch_size, 2)); ?> <?php echo e($formula->output_unit); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="px-4 py-6 text-center text-slate-500">No feed formulas found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="bg-white rounded-2xl border shadow-sm p-5">
                    <h2 class="text-lg font-semibold mb-4">Finished Feeds</h2>

                    <div class="space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $finishedFeeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="rounded-xl border px-4 py-3">
                                <div class="font-medium text-slate-900"><?php echo e($feed->name); ?></div>
                                <div class="text-sm text-slate-500"><?php echo e($feed->animal_type); ?></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-slate-500">No finished feeds found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-2xl border shadow-sm overflow-hidden">
                <div class="p-5 border-b">
                    <h2 class="text-lg font-semibold">Recent Mix Batches</h2>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-4 py-3 text-left">Batch No</th>
                                <th class="px-4 py-3 text-left">Date</th>
                                <th class="px-4 py-3 text-left">Formula</th>
                                <th class="px-4 py-3 text-left">Finished Feed</th>
                                <th class="px-4 py-3 text-left">Output</th>
                                <th class="px-4 py-3 text-left">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $mixBatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-t">
                                    <td class="px-4 py-3 font-medium"><?php echo e($batch->batch_no); ?></td>
                                    <td class="px-4 py-3"><?php echo e(optional($batch->production_date)->format('d M Y')); ?></td>
                                    <td class="px-4 py-3"><?php echo e($batch->formula->name ?? '—'); ?></td>
                                    <td class="px-4 py-3"><?php echo e($batch->finishedFeed->name ?? '—'); ?></td>
                                    <td class="px-4 py-3"><?php echo e(number_format($batch->actual_output ?? 0, 2)); ?></td>
                                    <td class="px-4 py-3"><?php echo e(ucfirst($batch->status)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="px-4 py-6 text-center text-slate-500">No mix batches yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/charlotte/chipper-farms/resources/views/feed-management/mixing.blade.php ENDPATH**/ ?>