<x-app-layout>
    @php
        $statusClasses = match($purchaseRequest->status) {
            'approved' => 'bg-green-100 text-green-800',
            'paid' => 'bg-emerald-100 text-emerald-800',
            'declined' => 'bg-red-100 text-red-800',
            'pending' => 'bg-blue-100 text-blue-800',
            default => 'bg-yellow-100 text-yellow-800',
        };
    @endphp

    <div class="max-w-6xl mx-auto py-6 px-4">
        <div class="mb-6 flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">Purchase Request Details</h1>
                <p class="text-sm text-gray-500">View purchase request information and requested items.</p>
            </div>

            <div class="flex flex-wrap items-center gap-3">
                @if($purchaseRequest->status === 'pending')
                    <a href="{{ route('purchase-requests.edit', $purchaseRequest) }}"
                       class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm transition">
                        Edit Request
                    </a>

                    <form action="{{ route('purchase-requests.destroy', $purchaseRequest) }}" method="POST"
                          onsubmit="return confirm('Are you sure you want to delete this purchase request?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit"
                                class="inline-flex items-center px-4 py-2 bg-red-700 hover:bg-red-800 text-white text-sm font-semibold rounded-lg shadow-sm transition">
                            Delete Request
                        </button>
                    </form>
                @endif

                @if(!in_array($purchaseRequest->status, ['approved', 'declined', 'paid']))
                    <form action="{{ route('purchase-requests.approve', $purchaseRequest) }}" method="POST">
                        @csrf
                        <button type="submit"
                                class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-semibold rounded-lg shadow-sm transition">
                            Approve Request
                        </button>
                    </form>

                    <form action="{{ route('purchase-requests.decline', $purchaseRequest) }}" method="POST" class="flex flex-wrap items-center gap-2">
                        @csrf
                        <input type="text"
                               name="decline_reason"
                               value="{{ old('decline_reason') }}"
                               placeholder="Reason for decline"
                               class="w-56 rounded-lg border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 text-sm">
                        <button type="submit"
                                class="inline-flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-semibold rounded-lg shadow-sm transition">
                            Decline Request
                        </button>
                    </form>
                @endif

                @if($purchaseRequest->status === 'approved')
                    <form action="{{ route('purchase-requests.mark-paid', $purchaseRequest) }}" method="POST">
                        @csrf
                        <label class="inline-flex items-center gap-3 px-4 py-2 bg-emerald-50 border border-emerald-200 rounded-lg cursor-pointer">
                            <input type="checkbox"
                                   onchange="this.form.submit()"
                                   class="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500">
                            <span class="text-sm font-semibold text-emerald-800">Mark as Paid</span>
                        </label>
                    </form>
                @endif

                <a href="{{ route('purchase-requests.index') }}"
                   class="inline-flex items-center px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 text-sm font-semibold rounded-lg transition">
                    Back
                </a>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow border border-gray-100 overflow-hidden mb-6">
            <div class="p-6 border-b border-gray-100">
                <h2 class="text-lg font-semibold text-gray-800">Request Information</h2>
            </div>

            <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <p class="text-sm text-gray-500 mb-1">Request No</p>
                    <p class="text-base font-semibold text-gray-800">{{ $purchaseRequest->request_no }}</p>
                </div>

                <div>
                    <p class="text-sm text-gray-500 mb-1">Request Date</p>
                    <p class="text-base font-semibold text-gray-800">
                        {{ optional($purchaseRequest->request_date)->format('M d, Y') ?? $purchaseRequest->request_date }}
                    </p>
                </div>

                <div>
                    <p class="text-sm text-gray-500 mb-1">Requested By</p>
                    <p class="text-base font-semibold text-gray-800">
                        {{ trim(($purchaseRequest->requester->first_name ?? '') . ' ' . ($purchaseRequest->requester->last_name ?? '')) ?: ($purchaseRequest->requester->name ?? 'N/A') }}
                    </p>
                </div>

                <div>
                    <p class="text-sm text-gray-500 mb-1">Status</p>
                    <p class="inline-flex px-3 py-1 rounded-full text-sm font-semibold {{ $statusClasses }}">
                        {{ ucfirst($purchaseRequest->status) }}
                    </p>
                </div>

                <div>
                    <p class="text-sm text-gray-500 mb-1">Approved By</p>
                    <p class="text-base font-semibold text-gray-800">
                        {{ trim(($purchaseRequest->approver->first_name ?? '') . ' ' . ($purchaseRequest->approver->last_name ?? '')) ?: ($purchaseRequest->approver->name ?? 'Not approved yet') }}
                    </p>
                </div>

                <div>
                    <p class="text-sm text-gray-500 mb-1">Approved At</p>
                    <p class="text-base font-semibold text-gray-800">
                        {{ $purchaseRequest->approved_at ? \Carbon\Carbon::parse($purchaseRequest->approved_at)->format('M d, Y h:i A') : '—' }}
                    </p>
                </div>

                <div class="md:col-span-2">
                    <p class="text-sm text-gray-500 mb-1">Purpose</p>
                    <p class="text-base text-gray-800">{{ $purchaseRequest->purpose ?: '—' }}</p>
                </div>

                <div class="md:col-span-2">
                    <p class="text-sm text-gray-500 mb-1">Notes</p>
                    <p class="text-base text-gray-800">{{ $purchaseRequest->notes ?: '—' }}</p>
                </div>

                @if($purchaseRequest->status === 'declined')
                    <div class="md:col-span-2">
                        <p class="text-sm text-gray-500 mb-1">Decline Reason</p>
                        <p class="text-base text-red-700 font-medium">
                            {{ $purchaseRequest->decline_reason ?: 'No reason provided.' }}
                        </p>
                    </div>
                @endif

                @if($purchaseRequest->status === 'paid')
                    <div class="md:col-span-2">
                        <p class="text-sm text-gray-500 mb-1">Payment Status</p>
                        <p class="text-base text-emerald-700 font-semibold">
                            This purchase request has been paid.
                        </p>
                    </div>
                @endif
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow border border-gray-100 overflow-hidden">
            <div class="p-6 border-b border-gray-100 flex items-center justify-between">
                <h2 class="text-lg font-semibold text-gray-800">Request Items</h2>
                <div class="text-sm text-gray-500">
                    Total Amount:
                    <span class="font-bold text-gray-800">{{ number_format($purchaseRequest->total_amount, 2) }}</span>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Item Name</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Description</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Quantity</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Unit Price</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Total Price</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 bg-white">
                        @forelse($purchaseRequest->items as $item)
                            <tr>
                                <td class="px-4 py-3">{{ $item->item_name }}</td>
                                <td class="px-4 py-3">{{ $item->description ?: '—' }}</td>
                                <td class="px-4 py-3">{{ number_format($item->quantity, 2) }}</td>
                                <td class="px-4 py-3">{{ number_format($item->unit_price, 2) }}</td>
                                <td class="px-4 py-3 font-semibold">{{ number_format($item->total_price, 2) }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="px-4 py-6 text-center text-gray-500">
                                    No items found for this purchase request.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-app-layout>